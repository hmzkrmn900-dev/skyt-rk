import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import CustomerDetail from './pages/CustomerDetail';
import DeviceDetail from './pages/DeviceDetail';
import Services from './pages/Services';
import NewService from './pages/NewService';
import Login from './pages/Login';
import AllDevices from './pages/AllDevices';
import Proposals from './pages/Proposals';
import Catalog from './pages/Catalog';
import Settings from './pages/Settings';
import Appointments from './pages/Appointments';
import SoldProducts from './pages/SoldProducts';
import Finance from './pages/Finance';

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { currentUser } = useApp();
  const sessionToken = localStorage.getItem('user');
  
  if (!currentUser || !sessionToken) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route path="/" element={<ProtectedRoute><Layout><Dashboard /></Layout></ProtectedRoute>} />
          <Route path="/customers" element={<ProtectedRoute><Layout><Customers /></Layout></ProtectedRoute>} />
          <Route path="/customers/:id" element={<ProtectedRoute><Layout><CustomerDetail /></Layout></ProtectedRoute>} />
          <Route path="/devices" element={<ProtectedRoute><Layout><AllDevices /></Layout></ProtectedRoute>} />
          <Route path="/devices/:id" element={<ProtectedRoute><Layout><DeviceDetail /></Layout></ProtectedRoute>} />
          <Route path="/sold-products" element={<ProtectedRoute><Layout><SoldProducts /></Layout></ProtectedRoute>} />
          <Route path="/appointments" element={<ProtectedRoute><Layout><Appointments /></Layout></ProtectedRoute>} />
          <Route path="/services" element={<ProtectedRoute><Layout><Services /></Layout></ProtectedRoute>} />
          <Route path="/services/new" element={<ProtectedRoute><Layout><NewService /></Layout></ProtectedRoute>} />
          <Route path="/catalog" element={<ProtectedRoute><Layout><Catalog /></Layout></ProtectedRoute>} />
          <Route path="/proposals" element={<ProtectedRoute><Layout><Proposals /></Layout></ProtectedRoute>} />
          <Route path="/finance" element={<ProtectedRoute><Layout><Finance /></Layout></ProtectedRoute>} />
          <Route path="/settings" element={<ProtectedRoute><Layout><Settings /></Layout></ProtectedRoute>} />
          
          {/* QR Code Redirect Support - Matches typical QR URLs */}
          <Route path="/device/:id" element={<Navigate replace to="/devices/:id" />} />
          
          {/* Default Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
}

export default App;
