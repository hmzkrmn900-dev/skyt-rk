import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://soagnxksmaupwxwvppaq.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNvYWdueGtzbWF1cHd4d3ZwcWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg1MjUzNDgsImV4cCI6MjA5NDEwMTM0OH0.T8TwhHfCTVTBrwjfy93HAMzwAVfdX6lo3FCUUEsLAuk';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
