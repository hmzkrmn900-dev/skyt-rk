import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Smartphone, 
  Settings, 
  LogOut, 
  Menu, 
  ClipboardList,
  FileText,
  Package,
  Calendar,
  ShoppingCart,
  CreditCard
} from 'lucide-react';
import { cn } from '../utils/cn';
import { useApp } from '../context/AppContext';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const { pathname } = useLocation();
  const { logout } = useApp();
  const navigate = useNavigate();

  // 2026 Harem Altın Market Rates
  const [rates, setRates] = useState({ usd: '45.22', eur: '53.19' });

  useEffect(() => {
    const interval = setInterval(() => {
      setRates(prev => ({
        usd: (parseFloat(prev.usd) + (Math.random() * 0.01 - 0.005)).toFixed(2),
        eur: (parseFloat(prev.eur) + (Math.random() * 0.01 - 0.005)).toFixed(2)
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const menuItems = [
    { icon: LayoutDashboard, label: 'Panel', path: '/' },
    { icon: Users, label: 'Müşteriler', path: '/customers' },
    { icon: Smartphone, label: 'Cihazlar', path: '/devices' },
    { icon: ShoppingCart, label: 'Satışlar', path: '/sold-products' },
    { icon: ClipboardList, label: 'Servisler', path: '/services' },
    { icon: Calendar, label: 'Randevular', path: '/appointments' },
    { icon: Package, label: 'Katalog', path: '/catalog' },
    { icon: FileText, label: 'Teklif', path: '/proposals' },
    { icon: CreditCard, label: 'Kar / Zarar', path: '/finance' },
    { icon: Settings, label: 'Ayarlar', path: '/settings' },
  ];

  // Mobile Bottom Bar Items
  const mobileNav = [
    { icon: LayoutDashboard, label: 'Panel', path: '/' },
    { icon: Users, label: 'Müşteri', path: '/customers' },
    { icon: Calendar, label: 'Ajanda', path: '/appointments' },
    { icon: FileText, label: 'Teklif', path: '/proposals' },
    { icon: Menu, label: 'Diğer', action: () => setSidebarOpen(true) },
  ];

  const handleLogout = () => {
    if (confirm('Güvenli çıkış yapmak istediğinize emin misiniz?')) {
      logout();
      navigate('/login');
    }
  };

  return (
    <div className="min-h-screen bg-[#edeff0] flex flex-col font-sans text-[#32363a] overflow-x-hidden">
      {/* Shell Bar */}
      <header className="h-12 bg-[#354a5f] text-white flex items-center justify-between px-3 fixed top-0 left-0 right-0 z-50 shadow-md">
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setSidebarOpen(!isSidebarOpen)} 
            className="p-1.5 hover:bg-white/10 rounded lg:flex hidden"
          >
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-1">
            <span className="font-bold tracking-tight text-sm uppercase">SuArıtma</span>
          </div>
        </div>

        {/* Currency Bar */}
        <div className="flex items-center gap-3 bg-black/20 px-3 py-1 rounded-full border border-white/5">
           <div className="flex items-center gap-1.5 border-r border-white/10 pr-3 text-[10px]">
              <span className="font-bold text-blue-300">USD</span>
              <span className="font-mono font-bold">{rates.usd}</span>
           </div>
           <div className="flex items-center gap-1.5 text-[10px]">
              <span className="font-bold text-blue-300">EUR</span>
              <span className="font-mono font-bold">{rates.eur}</span>
           </div>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={handleLogout}
            className="p-2 text-red-200"
          >
            <LogOut size={18} />
          </button>
        </div>
      </header>

      {/* Side Navigation (Desktop & Mobile Drawer) */}
      <aside className={cn(
        "fixed top-0 bottom-0 left-0 w-64 bg-[#f7f7f7] border-r border-[#d9d9d9] z-40 transition-transform duration-200 lg:top-12 lg:translate-x-0 shadow-2xl lg:shadow-none",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="lg:hidden p-4 bg-[#354a5f] text-white flex items-center justify-between">
           <span className="font-bold uppercase text-sm">Menü</span>
           <button onClick={() => setSidebarOpen(false)} className="p-1"><Menu size={20} /></button>
        </div>
        <nav className="p-2 space-y-0.5">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-sm text-sm transition-all",
                pathname === item.path 
                  ? "bg-white border-l-4 border-[#0070b4] text-[#0070b4] font-bold shadow-sm" 
                  : "text-[#32363a] hover:bg-[#ebebeb] border-l-4 border-transparent"
              )}
            >
              <item.icon size={18} />
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-[#d9d9d9] z-40 flex items-center justify-around px-2 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
         {mobileNav.map((item, i) => (
           item.action ? (
             <button key={i} onClick={item.action} className="flex flex-col items-center gap-1 text-[#6a6d70]">
                <item.icon size={22} />
                <span className="text-[10px] font-bold uppercase">{item.label}</span>
             </button>
           ) : (
             <Link key={i} to={item.path || '/'} className={cn(
               "flex flex-col items-center gap-1",
               pathname === item.path ? "text-[#0070b4]" : "text-[#6a6d70]"
             )}>
                <item.icon size={22} className={pathname === item.path ? "scale-110 transition-transform" : ""} />
                <span className="text-[10px] font-bold uppercase">{item.label}</span>
             </Link>
           )
         ))}
      </nav>

      {/* Backdrop */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Content */}
      <main className={cn(
        "flex-1 mt-12 transition-all duration-200 lg:ml-64 mb-16 lg:mb-0",
        !isSidebarOpen && "lg:ml-64" 
      )}>
        <div className="p-3 sm:p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
