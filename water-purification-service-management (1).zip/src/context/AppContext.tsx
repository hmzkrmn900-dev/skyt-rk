import React, { createContext, useContext, useState, useEffect } from 'react';
import { Customer, Device, ServiceRecord, User, Product, Appointment, SoldProduct } from '../types';
import { supabase } from '../lib/supabase';

interface AppContextType {
  customers: Customer[];
  devices: Device[];
  services: ServiceRecord[];
  currentUser: User | null;
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt'>) => Promise<void>;
  updateCustomer: (customer: Customer) => Promise<void>;
  addDevice: (device: Omit<Device, 'id' | 'qrCodeUrl'>) => Promise<void>;
  updateDevice: (device: Device) => Promise<void>;
  addService: (service: Omit<ServiceRecord, 'id'>) => Promise<void>;
  updateService: (service: ServiceRecord) => Promise<void>;
  login: (email: string, password?: string) => boolean;
  logout: () => void;
  updatePassword: (newPassword: string) => void;
  getCustomer: (id: string) => Customer | undefined;
  getDevice: (id: string) => Device | undefined;
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  appointments: Appointment[];
  addAppointment: (app: Omit<Appointment, 'id'>) => Promise<void>;
  updateAppointment: (app: Appointment) => Promise<void>;
  resetSystem: () => void;
  userNames: Record<string, string>;
  updateUserName: (id: string, name: string) => void;
  soldProducts: SoldProduct[];
  addSoldProduct: (sale: Omit<SoldProduct, 'id'>) => Promise<void>;
  deleteService: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [services, setServices] = useState<ServiceRecord[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [soldProducts, setSoldProducts] = useState<SoldProduct[]>([]);
  const [userNames, setUserNames] = useState<Record<string, string>>({});
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isCloudEnabled, setIsCloudEnabled] = useState(false);

  useEffect(() => {
    const isConfigured = !(supabase as any).supabaseUrl.includes('BURAYA_SUPABASE_URL_GELECEK');
    setIsCloudEnabled(isConfigured);

    const loadData = async () => {
      if (isConfigured) {
        try {
          const { data: custs } = await supabase.from('customers').select('*');
          const { data: devs } = await supabase.from('devices').select('*');
          const { data: servs } = await supabase.from('services').select('*');
          const { data: apps } = await supabase.from('appointments').select('*');
          const { data: sales } = await supabase.from('sold_products').select('*');

          if (custs) setCustomers(custs.map(c => ({
            id: c.id, tcNumber: c.tc_number, firstName: c.first_name, lastName: c.last_name,
            phone: c.phone, address: c.address, notes: c.notes, notePhotos: c.note_photos, createdAt: c.created_at
          })));
          if (devs) setDevices(devs.map(d => ({
            id: d.id, customerId: d.customer_id, brand: d.brand, model: d.model,
            serialNumber: d.serial_number, installationDate: d.installation_date,
            warrantyUntil: d.warranty_until, filters: d.filters, qrCodeUrl: `${window.location.origin}/device/${d.id}`
          })));
          if (servs) setServices(servs.map(s => ({
            id: s.id, deviceId: s.device_id, technicianId: s.technician_id, type: s.type,
            tdsIn: s.tds_in, tdsOut: s.tds_out, pressure: s.pressure, operations: s.operations,
            partsChanged: [], photoUrls: [],
            notes: s.notes, customerSignature: s.customer_signature, totalAmount: s.total_amount,
            paymentStatus: s.payment_status, paymentMethod: s.payment_method, date: s.date
          })));
          if (apps) setAppointments(apps.map(a => ({
            id: a.id, customerId: a.customer_id, date: a.date, time: a.time, description: a.description, status: a.status
          })));
          if (sales) setSoldProducts(sales.map(s => ({
            id: s.id, customerId: s.customer_id, productId: s.product_id, date: s.date, price: s.price, technicianId: s.technician_id
          })));
        } catch (e) { console.error("Cloud error:", e); }
      } else {
        const saved = localStorage.getItem('customers');
        if (saved) setCustomers(JSON.parse(saved));
      }
    };
    loadData();

    const savedUser = localStorage.getItem('user');
    const savedProducts = localStorage.getItem('products');
    const savedUserNames = localStorage.getItem('user_names');
    if (savedUser) setCurrentUser(JSON.parse(savedUser));
    if (savedUserNames) setUserNames(JSON.parse(savedUserNames));
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    else {
      const initial = [{ id: 'p1', name: '5 Aşamalı Eco Cihaz', price: 4250, category: 'Cihaz' }, { id: 'p2', name: '7 Aşamalı Alkali Pro', price: 5800, category: 'Cihaz' }];
      setProducts(initial);
    }
  }, []);

  const addCustomer = async (data: Omit<Customer, 'id' | 'createdAt'>) => {
    if (isCloudEnabled) {
      const { data: newCust, error } = await supabase.from('customers').insert([{
        tc_number: data.tcNumber, first_name: data.firstName, last_name: data.lastName, phone: data.phone, address: data.address, notes: data.notes
      }]).select().single();
      if (!error && newCust) setCustomers([...customers, { ...data, id: newCust.id, createdAt: newCust.created_at }]);
    } else {
      const n = { ...data, id: Math.random().toString(36).substr(2, 9), createdAt: new Date().toISOString() };
      setCustomers([...customers, n]);
    }
  };

  const updateCustomer = async (customer: Customer) => {
    if (isCloudEnabled) await supabase.from('customers').update({ notes: customer.notes, note_photos: customer.notePhotos }).eq('id', customer.id);
    setCustomers(customers.map(c => c.id === customer.id ? customer : c));
  };

  const addDevice = async (data: Omit<Device, 'id' | 'qrCodeUrl'>) => {
    const id = `CHZ-${(devices.length + 1).toString().padStart(4, '0')}`;
    if (isCloudEnabled) await supabase.from('devices').insert([{ id, customer_id: data.customerId, brand: data.brand, model: data.model, serial_number: data.serialNumber, installation_date: data.installationDate, warranty_until: data.warrantyUntil, filters: data.filters }]);
    setDevices([...devices, { ...data, id, qrCodeUrl: `${window.location.origin}/device/${id}` }]);
  };

  const updateDevice = async (device: Device) => {
    if (isCloudEnabled) await supabase.from('devices').update({ filters: device.filters }).eq('id', device.id);
    setDevices(devices.map(d => d.id === device.id ? device : d));
  };

  const addService = async (data: Omit<ServiceRecord, 'id'>) => {
    if (isCloudEnabled) await supabase.from('services').insert([{ device_id: data.deviceId, technician_id: data.technicianId, type: data.type, tds_in: data.tdsIn, tds_out: data.tdsOut, pressure: data.pressure, operations: data.operations, notes: data.notes, customer_signature: data.customerSignature, total_amount: data.totalAmount, payment_status: data.paymentStatus, payment_method: data.paymentMethod }]);
    setServices([...services, { ...data, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const updateService = async (service: ServiceRecord) => {
    setServices(services.map(s => s.id === service.id ? service : s));
  };

  const deleteService = async (id: string) => {
    if (isCloudEnabled) await supabase.from('services').delete().eq('id', id);
    setServices(services.filter(s => s.id !== id));
  };

  const addAppointment = async (data: Omit<Appointment, 'id'>) => {
    if (isCloudEnabled) await supabase.from('appointments').insert([{ customer_id: data.customerId, date: data.date, time: data.time, description: data.description, status: data.status }]);
    setAppointments([...appointments, { ...data, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const updateAppointment = async (app: Appointment) => {
    if (isCloudEnabled) await supabase.from('appointments').update({ status: app.status }).eq('id', app.id);
    setAppointments(appointments.map(a => a.id === app.id ? app : a));
  };

  const addSoldProduct = async (data: Omit<SoldProduct, 'id'>) => {
    if (isCloudEnabled) await supabase.from('sold_products').insert([{ customer_id: data.customerId, product_id: data.productId, date: data.date, price: data.price, technician_id: data.technicianId }]);
    setSoldProducts([...soldProducts, { ...data, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const login = (id: string, password?: string) => {
    const validIds = ['5550240995', '5465307039'];
    const currentPass = localStorage.getItem('system_password') || '445768';
    if (validIds.includes(id) && password === currentPass) {
      const savedNames = JSON.parse(localStorage.getItem('user_names') || '{}');
      const user: User = { id: '1', name: savedNames[id] || 'Teknisyen', role: 'ADMIN', email: id };
      setCurrentUser(user);
      localStorage.setItem('user', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => { setCurrentUser(null); localStorage.removeItem('user'); };
  const updatePassword = (newPass: string) => { localStorage.setItem('system_password', newPass); };
  const addProduct = (data: Omit<Product, 'id'>) => setProducts([...products, { ...data, id: Math.random().toString(36).substr(2, 9) }]);
  const updateProduct = (p: Product) => setProducts(products.map(item => item.id === p.id ? p : item));
  const deleteProduct = (id: string) => setProducts(products.filter(p => p.id !== id));
  const updateUserName = (id: string, name: string) => { const n = { ...userNames, [id]: name }; setUserNames(n); localStorage.setItem('user_names', JSON.stringify(n)); };
  const resetSystem = () => { localStorage.clear(); window.location.reload(); };
  const getCustomer = (id: string) => customers.find(c => c.id === id);
  const getDevice = (id: string) => devices.find(d => d.id === id);

  return (
    <AppContext.Provider value={{
      customers, devices, services, products, currentUser, appointments, userNames, soldProducts,
      addCustomer, updateCustomer, addDevice, updateDevice, addService, updateService, addProduct, updateProduct, deleteProduct,
      addAppointment, updateAppointment, updateUserName, resetSystem, addSoldProduct, deleteService,
      login, logout, updatePassword, getCustomer, getDevice
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
