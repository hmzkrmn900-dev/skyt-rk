import React, { useState } from 'react';
import { 
  Plus, 
  MoreVertical, 
  CheckCircle2, 
  AlertCircle,
  TrendingUp,
  FileText
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

const Appointments: React.FC = () => {
  const { appointments, customers, addAppointment, updateAppointment } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    customerId: '',
    date: new Date().toISOString().split('T')[0],
    time: '10:00',
    description: ''
  });

  const sortedAppointments = [...appointments].sort((a, b) => {
    return new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime();
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addAppointment({
      ...formData,
      status: 'PENDING'
    });
    setShowAddModal(false);
    setFormData({ customerId: '', date: new Date().toISOString().split('T')[0], time: '10:00', description: '' });
  };

  const toggleStatus = (app: any) => {
    updateAppointment({
      ...app,
      status: app.status === 'COMPLETED' ? 'PENDING' : 'COMPLETED'
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      <div className="bg-white border border-[#d9d9d9] shadow-sm">
        <div className="p-4 border-b border-[#f2f2f2] flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#32363a]">Randevu Takvimi</h2>
          <button 
            onClick={() => setShowAddModal(true)}
            className="px-4 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
          >
            Randevu Ekle
          </button>
        </div>
      </div>

      {/* Akıllı SMS Hatırlatma Sistemi */}
      <section className="bg-blue-600 text-white p-6 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
         <div className="text-center sm:text-left">
            <h3 className="text-sm font-bold uppercase tracking-widest flex items-center justify-center sm:justify-start gap-2">
               <TrendingUp size={18} /> Akıllı SMS Hatırlatma
            </h3>
            <p className="text-[11px] opacity-80 mt-1">Günü gelen randevuları tarayın ve müşterilere otomatik SMS bilgilendirmesi gönderin.</p>
         </div>
         <button 
           onClick={() => {
              const pending = appointments.filter(a => a.status === 'PENDING').length;
              if (pending === 0) return alert('Hatırlatılacak randevu bulunamadı.');
              if (confirm(`${pending} müşteriye SMS hatırlatması gönderilecektir. Onaylıyor musunuz?`)) {
                alert('İşlem Başlatıldı: SMS kuyruğuna alındı.');
              }
           }}
           className="w-full sm:w-auto px-6 py-2 bg-white text-blue-600 text-xs font-bold uppercase tracking-widest active:bg-blue-50 transition-colors shadow-md"
         >
           Tümüne SMS Gönder
         </button>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Appointments List */}
        <div className="lg:col-span-8 space-y-3">
          {sortedAppointments.length === 0 ? (
            <div className="bg-white border border-[#d9d9d9] border-dashed p-12 text-center text-[#6a6d70] italic">
               Henüz kayıtlı randevu bulunmuyor.
            </div>
          ) : (
            sortedAppointments.map((app) => {
              const customer = customers.find(c => c.id === app.customerId);
              const isCompleted = app.status === 'COMPLETED';
              
              return (
                <div key={app.id} className={cn(
                  "bg-white border border-[#d9d9d9] p-4 flex items-center justify-between hover:border-[#0070b4] transition-all",
                  isCompleted && "opacity-60 grayscale bg-[#f9f9f9]"
                )}>
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 flex flex-col items-center justify-center border",
                      isCompleted ? "bg-[#f2f2f2] border-[#d9d9d9]" : "bg-[#f5f9fc] border-[#0070b4] text-[#0070b4]"
                    )}>
                       <span className="text-[10px] font-bold uppercase leading-none">{new Date(app.date).toLocaleDateString('tr-TR', { month: 'short' })}</span>
                       <span className="text-lg font-light leading-tight">{new Date(app.date).getDate()}</span>
                    </div>
                    <div className="space-y-0.5">
                       <div className="flex items-center gap-2">
                          <p className="font-bold text-[#32363a]">{customer?.firstName} {customer?.lastName}</p>
                          <span className="text-[10px] bg-[#f2f2f2] px-1 font-bold text-[#6a6d70]">{app.time}</span>
                       </div>
                       <p className="text-xs text-[#6a6d70] line-clamp-1">{app.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => toggleStatus(app)}
                      className={cn(
                        "p-2 rounded transition-colors",
                        isCompleted ? "text-emerald-600 bg-emerald-50" : "text-[#6a6d70] hover:bg-[#f2f2f2]"
                      )}
                    >
                      <CheckCircle2 size={20} />
                    </button>
                    <button 
                      onClick={() => {
                        const msg = `Sayin ${customer?.firstName} ${customer?.lastName}, randevunuzu hatirlatmak isteriz.`;
                        alert(`SMS Gonderildi: ${customer?.phone}\nMesaj: ${msg}`);
                      }}
                      className="p-2 text-[#0070b4] hover:bg-[#f5f9fc] rounded"
                      title="SMS Gönder"
                    >
                      <FileText size={18} />
                    </button>
                    <button className="p-2 text-[#6a6d70] hover:bg-[#f2f2f2] rounded">
                      <MoreVertical size={20} />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Calendar Stats Widget */}
        <div className="lg:col-span-4 space-y-6">
           <section className="bg-white border border-[#d9d9d9] p-6 shadow-sm">
              <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider border-b border-[#f2f2f2] pb-3 mb-4">Görev Özeti</h3>
              <div className="space-y-4">
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-[#6a6d70]">
                       <AlertCircle size={14} className="text-amber-600" /> Bekleyen
                    </div>
                    <span className="font-bold text-sm">{appointments.filter(a => a.status === 'PENDING').length}</span>
                 </div>
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-[#6a6d70]">
                       <CheckCircle2 size={14} className="text-emerald-600" /> Tamamlanan
                    </div>
                    <span className="font-bold text-sm">{appointments.filter(a => a.status === 'COMPLETED').length}</span>
                 </div>
              </div>
           </section>
        </div>
      </div>

      {/* Add Appointment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-[1px]" onClick={() => setShowAddModal(false)} />
          <div className="bg-white border border-[#d9d9d9] w-full max-w-md relative z-[101] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider">Randevu Planla</h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#6a6d70] p-1"><Plus className="rotate-45" size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70]">Müşteri Seçin</label>
                <select 
                  required
                  className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                  value={formData.customerId}
                  onChange={e => setFormData({...formData, customerId: e.target.value})}
                >
                  <option value="">Seçiniz...</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6a6d70]">Tarih</label>
                  <input required type="date" className="w-full px-3 py-2 border border-[#d9d9d9] text-sm" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6a6d70]">Saat</label>
                  <input required type="time" className="w-full px-3 py-2 border border-[#d9d9d9] text-sm" value={formData.time} onChange={e => setFormData({...formData, time: e.target.value})} />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70]">Açıklama</label>
                <textarea rows={2} className="w-full px-3 py-2 border border-[#d9d9d9] text-sm outline-none focus:border-[#0070b4] resize-none" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>

              <div className="flex gap-2 justify-end pt-4 border-t border-[#f2f2f2]">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-6 py-1.5 text-xs font-bold text-[#32363a] hover:bg-[#f2f2f2]">İptal</button>
                <button type="submit" className="px-6 py-1.5 bg-[#0070b4] text-white text-xs font-bold border border-[#0070b4] hover:bg-[#005a92]">Ekle</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Appointments;
