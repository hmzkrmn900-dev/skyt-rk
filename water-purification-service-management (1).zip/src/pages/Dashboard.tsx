import React from 'react';
import { 
  Users, 
  Smartphone, 
  Clock, 
  CheckCircle2,
  Calendar,
  Wrench,
  ChevronRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';
import { cn } from '../utils/cn';

const Dashboard: React.FC = () => {
  const { customers, devices, services, appointments } = useApp();

  const tiles = [
    { label: 'Müşteriler', subLabel: 'Yönetim Listesi', value: customers.length, icon: Users, path: '/customers', color: 'text-[#0070b4]' },
    { label: 'Cihazlar', subLabel: 'Tüm Envanter', value: devices.length, icon: Smartphone, path: '/devices', color: 'text-[#0070b4]' },
    { label: 'Bekleyenler', subLabel: 'Açık İşler', value: appointments.filter(a => a.status === 'PENDING').length, icon: Clock, path: '/appointments', color: 'text-[#e9730c]' },
    { label: 'Tamamlanan', subLabel: 'Servis Arşivi', value: services.length, icon: CheckCircle2, path: '/services', color: 'text-emerald-600' },
  ];

  // Mock Chart Data based on actual service counts if any, else static for visual
  const chartData = [
    { name: 'Oca', count: services.length || 2 },
    { name: 'Şub', count: 5 },
    { name: 'Mar', count: 3 },
    { name: 'Nis', count: 8 },
    { name: 'May', count: 12 },
  ];

  const upcomingMaintenances = devices.flatMap(d => 
    d.filters.filter(f => f.status === 'warning' || f.status === 'critical')
    .map(f => ({ ...f, deviceName: `${d.brand} ${d.model}`, customerName: customers.find(c => c.id === d.customerId)?.lastName }))
  ).slice(0, 4);

  const recentServices = [...services].reverse().slice(0, 4);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 md:pb-8">
      <header className="mb-4 flex items-center justify-between px-1">
        <div>
          <h2 className="text-lg font-bold text-[#32363a] uppercase tracking-tight">Kontrol Paneli</h2>
          <div className="h-1 w-8 bg-[#0070b4] mt-0.5"></div>
        </div>
      </header>

      {/* Fiori Launchpad Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {tiles.map((tile, i) => (
          <Link 
            key={i} 
            to={tile.path}
            className="group bg-white border border-[#d9d9d9] active:border-[#0070b4] hover:shadow-md transition-all p-3 sm:p-4 flex flex-col justify-between h-32 sm:h-40 relative overflow-hidden"
          >
            <div className="flex justify-between items-start">
              <div className="space-y-0.5">
                <p className="text-xs sm:text-sm font-bold text-[#32363a] leading-tight">{tile.label}</p>
                <p className="text-[10px] text-[#6a6d70]">{tile.subLabel}</p>
              </div>
              <tile.icon size={18} className={cn("transition-transform group-active:scale-110", tile.color)} />
            </div>
            <div className="mt-auto">
              <span className="text-2xl sm:text-3xl font-light text-[#32363a]">{tile.value}</span>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <div className="lg:col-span-2 bg-white border border-[#d9d9d9] p-4 sm:p-6 shadow-sm">
           <div className="flex items-center justify-between mb-6">
              <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-widest flex items-center gap-2">
                 <Calendar size={14} className="text-[#0070b4]" /> Servis Yoğunluğu
              </h3>
           </div>
           <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f2f2f2" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6a6d70', fontSize: 11}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#6a6d70', fontSize: 11}} />
                  <Tooltip 
                    cursor={{fill: '#f8fafc'}}
                    contentStyle={{ border: '1px solid #d9d9d9', borderRadius: '0', fontSize: '11px' }}
                  />
                  <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                    {chartData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={index === chartData.length - 1 ? '#0070b4' : '#d9d9d9'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* Action Center - Small widgets */}
        <div className="space-y-6">
           <section className="bg-white border border-[#d9d9d9] shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center justify-between">
                 <h3 className="text-[10px] font-bold text-[#32363a] uppercase tracking-widest">Yaklaşan Bakımlar</h3>
                 <span className="text-[10px] font-bold text-[#bb0000]">{upcomingMaintenances.length} KRİTİK</span>
              </div>
              <div className="divide-y divide-[#f2f2f2]">
                 {upcomingMaintenances.length > 0 ? upcomingMaintenances.map((m, i) => (
                   <div key={i} className="p-3 flex items-center justify-between hover:bg-[#f9f9f9]">
                      <div className="flex items-center gap-3">
                         <div className="w-1.5 h-1.5 rounded-full bg-[#e9730c]"></div>
                         <div>
                            <p className="text-xs font-bold text-[#32363a]">{m.customerName}</p>
                            <p className="text-[10px] text-[#6a6d70]">{m.name}</p>
                         </div>
                      </div>
                      <ChevronRight size={14} className="text-[#d9d9d9]" />
                   </div>
                 )) : (
                   <p className="p-8 text-center text-xs text-[#6a6d70] italic">Kritik bakım bulunmuyor.</p>
                 )}
              </div>
           </section>

           <section className="bg-white border border-[#d9d9d9] shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-[#f2f2f2] bg-[#fcfcfc]">
                 <h3 className="text-[10px] font-bold text-[#32363a] uppercase tracking-widest">Yapılan Bakımlar</h3>
              </div>
              <div className="divide-y divide-[#f2f2f2]">
                 {recentServices.length > 0 ? recentServices.map((s, i) => (
                   <div key={i} className="p-3 flex items-center gap-3 hover:bg-[#f9f9f9]">
                      <div className="p-1.5 bg-emerald-50 text-emerald-600">
                         <Wrench size={14} />
                      </div>
                      <div>
                         <p className="text-xs font-bold text-[#32363a]">{new Date(s.date).toLocaleDateString('tr-TR')}</p>
                         <p className="text-[10px] text-[#6a6d70]">{s.type === 'MAINTENANCE' ? 'Periyodik Bakım' : 'Onarım'}</p>
                      </div>
                   </div>
                 )) : (
                   <p className="p-8 text-center text-xs text-[#6a6d70] italic">Henüz servis kaydı yok.</p>
                 )}
              </div>
           </section>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
