import React, { useState } from 'react';
import { 
  Smartphone, 
  Search, 
  Filter, 
  ChevronRight,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';
import { cn } from '../utils/cn';

const AllDevices: React.FC = () => {
  const { devices, customers } = useApp();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredDevices = devices.filter(d => {
    const customer = customers.find(c => c.id === d.customerId);
    const searchStr = `${d.brand} ${d.model} ${d.serialNumber} ${customer?.firstName} ${customer?.lastName}`.toLowerCase();
    return searchStr.includes(searchTerm.toLowerCase());
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Tüm Cihazlar</h2>
          <p className="text-slate-500">Sistemdeki tüm kayıtlı su arıtma cihazları.</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Marka, model veya seri no ile ara..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors font-medium">
          <Filter size={20} />
          Filtrele
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Cihaz Bilgisi</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Müşteri</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Montaj</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Filtre Durumu</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDevices.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    <Smartphone size={40} className="mx-auto mb-2 opacity-20" />
                    Cihaz bulunamadı.
                  </td>
                </tr>
              ) : (
                filteredDevices.map((device) => {
                  const customer = customers.find(c => c.id === device.customerId);
                  const hasWarning = device.filters.some(f => f.status === 'critical' || f.status === 'warning');
                  
                  return (
                    <tr key={device.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center",
                            hasWarning ? "bg-amber-50 text-amber-600" : "bg-blue-50 text-blue-600"
                          )}>
                            <Smartphone size={20} />
                          </div>
                          <div>
                            <p className="text-sm font-bold text-slate-900">{device.brand} {device.model}</p>
                            <p className="text-xs text-slate-500">S/N: {device.serialNumber}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <Link to={`/customers/${customer?.id}`} className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors underline decoration-slate-200">
                          {customer?.firstName} {customer?.lastName}
                        </Link>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-xs font-bold text-slate-900">{new Date(device.installationDate).toLocaleDateString('tr-TR')}</p>
                      </td>
                      <td className="px-6 py-4">
                         {hasWarning ? (
                           <span className="flex items-center gap-1.5 text-xs font-bold text-amber-600 px-2 py-1 bg-amber-50 rounded-lg w-fit">
                             <AlertTriangle size={12} /> Bakım Gerekli
                           </span>
                         ) : (
                           <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 px-2 py-1 bg-emerald-50 rounded-lg w-fit">
                             <ShieldCheck size={12} /> Normal
                           </span>
                         )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Link 
                          to={`/devices/${device.id}`}
                          className="p-2 text-slate-300 hover:text-blue-600 transition-colors inline-block"
                        >
                          <ChevronRight size={20} />
                        </Link>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AllDevices;
