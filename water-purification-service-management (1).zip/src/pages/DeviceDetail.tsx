import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Smartphone, 
  History, 
  ChevronRight,
  Droplets,
  Wrench
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

const DeviceDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { devices, customers, services } = useApp();
  
  const device = devices.find(d => d.id === id);
  const customer = customers.find(c => c.id === device?.customerId);
  const deviceServices = services.filter(s => s.deviceId === id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  if (!device) {
    return (
      <div className="p-8 bg-white border border-[#d9d9d9] text-center">
        <p className="text-[#6a6d70]">Cihaz kaydı bulunamadı.</p>
        <Link to="/devices" className="text-[#0070b4] font-bold mt-2 inline-block hover:underline text-sm">Listeye Dön</Link>
      </div>
    );
  }

  return (
    <div className="-m-4 lg:-m-8">
      {/* Fiori Object Page Header */}
      <header className="bg-white border-b border-[#d9d9d9] px-4 md:px-8 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 text-[11px] font-bold text-[#0070b4] mb-4 uppercase tracking-wider">
            <Link to="/devices" className="hover:underline">Cihazlar</Link>
            <ChevronRight size={12} />
            <span className="text-[#6a6d70]">{device.id}</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 bg-[#f2f2f2] border border-[#d9d9d9] flex items-center justify-center text-[#0070b4]">
                <Smartphone size={40} strokeWidth={1.5} />
              </div>
              <div className="space-y-1">
                <h2 className="text-2xl font-light text-[#32363a]">{device.brand} {device.model}</h2>
                <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                   <div className="flex items-center gap-2 text-[#6a6d70]">
                      <span className="font-bold">Müşteri:</span> {customer?.firstName} {customer?.lastName}
                   </div>
                   <div className="flex items-center gap-2 text-[#6a6d70]">
                      <span className="font-bold">Seri No:</span> {device.serialNumber}
                   </div>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-1.5 bg-white text-[#0070b4] text-sm font-bold border border-[#d9d9d9] hover:bg-[#f2f2f2]">
                QR Kod Yazdır
              </button>
              <Link 
                to={`/services/new?deviceId=${device.id}`}
                className="px-4 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
              >
                Servis Formu Aç
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Fiori Object Page Content */}
      <div className="max-w-7xl mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Filter Status Section */}
          <section className="bg-white border border-[#d9d9d9] shadow-sm">
            <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
              <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider flex items-center gap-2">
                <Droplets size={16} className="text-[#0070b4]" />
                Filtre Ömür Takibi
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[#f2f2f2] bg-[#f9f9f9]">
                    <th className="px-6 py-3 font-bold text-[#6a6d70]">Filtre</th>
                    <th className="px-6 py-3 font-bold text-[#6a6d70]">Son Değişim</th>
                    <th className="px-6 py-3 font-bold text-[#6a6d70]">Planlanan</th>
                    <th className="px-6 py-3 font-bold text-[#6a6d70] text-center">Durum</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f2f2f2]">
                  {device.filters.map((filter, i) => (
                    <tr key={i}>
                      <td className="px-6 py-4 font-medium text-[#32363a]">{filter.name}</td>
                      <td className="px-6 py-4 text-[#6a6d70]">{new Date(filter.lastChanged).toLocaleDateString('tr-TR')}</td>
                      <td className="px-6 py-4 text-[#6a6d70]">{filter.nextChange ? new Date(filter.nextChange).toLocaleDateString('tr-TR') : '-'}</td>
                      <td className="px-6 py-4">
                        <div className="flex justify-center">
                          <div className={cn(
                            "w-2.5 h-2.5 rounded-full",
                            filter.status === 'good' ? "bg-emerald-500" :
                            filter.status === 'warning' ? "bg-amber-500" : "bg-red-500"
                          )} title={filter.status.toUpperCase()} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Service History Table */}
          <section className="bg-white border border-[#d9d9d9] shadow-sm">
            <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
              <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider flex items-center gap-2">
                <History size={16} className="text-[#6a6d70]" />
                Servis Tarihçesi
              </h3>
            </div>
            <div className="divide-y divide-[#f2f2f2]">
              {deviceServices.map((service) => (
                <div key={service.id} className="px-6 py-4 flex items-center justify-between hover:bg-[#f5f9fc] transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#f2f2f2] text-[#6a6d70] flex items-center justify-center border border-[#d9d9d9] group-hover:bg-[#0070b4] group-hover:text-white transition-colors">
                      <Wrench size={18} />
                    </div>
                    <div>
                      <p className="font-bold text-[#32363a]">{service.type === 'MAINTENANCE' ? 'Periyodik Bakım' : 'Onarım'}</p>
                      <p className="text-[11px] text-[#6a6d70]">{new Date(service.date).toLocaleDateString('tr-TR')}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                       <p className="text-sm font-bold text-[#32363a]">{service.totalAmount} TL</p>
                       <span className="text-[10px] font-bold text-emerald-600 uppercase">Tamamlandı</span>
                    </div>
                    <Link to={`/services`} className="text-[#0070b4]">
                      <ChevronRight size={18} />
                    </Link>
                  </div>
                </div>
              ))}
              {deviceServices.length === 0 && (
                <div className="p-8 text-center text-[#6a6d70] italic text-sm">
                  Kayıtlı servis bulunmuyor.
                </div>
              )}
            </div>
          </section>
        </div>

        {/* Sidebar Facets */}
        <div className="space-y-8">
           <section className="bg-white border border-[#d9d9d9] p-6 text-center flex flex-col items-center">
              <div className="p-3 bg-[#f7f7f7] border border-[#d9d9d9] mb-4">
                 <QRCodeSVG value={device.qrCodeUrl} size={140} level="M" />
              </div>
              <h4 className="text-sm font-bold text-[#32363a]">Benzersiz Cihaz Kimliği</h4>
              <p className="text-[11px] text-[#6a6d70] mt-2 leading-relaxed">
                Bu QR kodu okutularak cihaz kartına doğrudan erişim sağlanabilir.
              </p>
              <button className="mt-4 w-full py-2 bg-[#f2f2f2] text-[#0070b4] text-xs font-bold border border-[#d9d9d9] hover:bg-[#ebebeb]">
                Etiket Oluştur
              </button>
           </section>

           <section className="bg-white border border-[#d9d9d9] p-6 space-y-4">
              <h4 className="text-xs font-bold text-[#32363a] uppercase tracking-wider border-b border-[#f2f2f2] pb-2">Hızlı Durum</h4>
              <div className="space-y-3">
                 <div className="flex items-center justify-between text-xs">
                    <span className="text-[#6a6d70]">Garanti Durumu:</span>
                    <span className="font-bold text-emerald-600">Aktif</span>
                 </div>
                 <div className="flex items-center justify-between text-xs">
                    <span className="text-[#6a6d70]">Son TDS Ölçümü:</span>
                    <span className="font-bold text-[#32363a]">12 ppm</span>
                 </div>
                 <div className="flex items-center justify-between text-xs">
                    <span className="text-[#6a6d70]">Cihaz Ömrü:</span>
                    <span className="font-bold text-[#32363a]">18 Ay</span>
                 </div>
              </div>
           </section>
        </div>
      </div>
    </div>
  );
};

export default DeviceDetail;
