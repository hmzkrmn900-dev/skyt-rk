import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ArrowUpRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

const Finance: React.FC = () => {
  const { services, soldProducts } = useApp();
  const [period, setFilterPeriod] = useState<'MONTHLY' | 'YEARLY'>('MONTHLY');

  // Calculation Logic
  const serviceRevenue = services.reduce((acc, s) => acc + s.totalAmount, 0);
  const salesRevenue = soldProducts.reduce((acc, s) => acc + s.price, 0);
  const totalRevenue = serviceRevenue + salesRevenue;

  // Mock costs (45% for parts, fuel, labor)
  const estimatedCost = totalRevenue * 0.45;
  const netProfit = totalRevenue - estimatedCost;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-[#32363a]">Mali Analiz (Kar/Zarar)</h2>
          <div className="h-0.5 w-8 bg-[#0070b4] mt-1"></div>
        </div>
        <div className="flex bg-white border border-[#d9d9d9] p-1 gap-1">
           <button onClick={() => setFilterPeriod('MONTHLY')} className={cn("px-4 py-1 text-[10px] font-bold transition-all uppercase", period === 'MONTHLY' ? "bg-[#354a5f] text-white" : "text-[#6a6d70] hover:bg-[#f2f2f2]")}>AYLIK</button>
           <button onClick={() => setFilterPeriod('YEARLY')} className={cn("px-4 py-1 text-[10px] font-bold transition-all uppercase", period === 'YEARLY' ? "bg-[#354a5f] text-white" : "text-[#6a6d70] hover:bg-[#f2f2f2]")}>YILLIK</button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
         <div className="bg-white border border-[#d9d9d9] p-5 shadow-sm">
            <div className="flex justify-between items-start mb-4">
               <div className="p-2 bg-blue-50 text-[#0070b4] border border-[#0070b4]/10"><TrendingUp size={20} /></div>
               <span className="text-[10px] font-bold text-emerald-600">BRÜT</span>
            </div>
            <p className="text-[10px] font-bold text-[#6a6d70] uppercase tracking-wider">Toplam Gelir</p>
            <p className="text-xl font-bold text-[#32363a] mt-1">{totalRevenue.toLocaleString('tr-TR')} TL</p>
         </div>

         <div className="bg-white border border-[#d9d9d9] p-5 shadow-sm">
            <div className="flex justify-between items-start mb-4">
               <div className="p-2 bg-red-50 text-[#bb0000] border border-[#bb0000]/10"><TrendingDown size={20} /></div>
               <span className="text-[10px] font-bold text-[#bb0000]">GİDER</span>
            </div>
            <p className="text-[10px] font-bold text-[#6a6d70] uppercase tracking-wider">Tahmini Maliyet</p>
            <p className="text-xl font-bold text-[#32363a] mt-1">{estimatedCost.toLocaleString('tr-TR')} TL</p>
         </div>

         <div className="bg-[#354a5f] text-white p-5 shadow-md border-b-4 border-emerald-500">
            <div className="flex justify-between items-start mb-4">
               <div className="p-2 bg-white/10 text-white"><DollarSign size={20} /></div>
               <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-400">NET KAR <ArrowUpRight size={14} /></div>
            </div>
            <p className="text-[10px] font-bold opacity-70 uppercase tracking-wider">Net Karlılık</p>
            <p className="text-xl font-bold mt-1">{netProfit.toLocaleString('tr-TR')} TL</p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
         <section className="bg-white border border-[#d9d9d9] p-5 shadow-sm">
            <h3 className="text-[10px] font-bold text-[#32363a] uppercase tracking-widest mb-6 pb-2 border-b border-[#f2f2f2]">Gelir Dağılımı</h3>
            <div className="space-y-3">
               <div className="flex items-center justify-between p-3 bg-[#f9f9f9] border-l-4 border-[#0070b4]">
                  <span className="text-xs font-bold text-[#32363a]">Teknik Servis Gelirleri</span>
                  <span className="font-bold text-[#0070b4]">{serviceRevenue.toLocaleString('tr-TR')} TL</span>
               </div>
               <div className="flex items-center justify-between p-3 bg-[#f9f9f9] border-l-4 border-[#e9730c]">
                  <span className="text-xs font-bold text-[#32363a]">Ürün Satış Gelirleri</span>
                  <span className="font-bold text-[#e9730c]">{salesRevenue.toLocaleString('tr-TR')} TL</span>
               </div>
            </div>
         </section>

         <section className="bg-white border border-[#d9d9d9] p-5 shadow-sm">
            <h3 className="text-[10px] font-bold text-[#32363a] uppercase tracking-widest mb-6 pb-2 border-b border-[#f2f2f2]">CRM & SMS Raporu</h3>
            <div className="text-center py-6">
               <div className="inline-flex p-4 bg-[#f5f9fc] rounded-full mb-4">
                  <TrendingUp size={32} className="text-[#0070b4] opacity-50" />
               </div>
               <p className="text-[11px] text-[#6a6d70] italic max-w-xs mx-auto">Gerçek SMS API bağlantısı yapıldığında geri dönüş oranları burada analiz edilecektir.</p>
            </div>
         </section>
      </div>
    </div>
  );
};

export default Finance;
