import React, { useState } from 'react';
import { 
  Plus, 
  ShoppingCart, 
  Calendar,
  User,
  TrendingUp,
  Tag
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const SoldProducts: React.FC = () => {
  const { customers, products, soldProducts, addSoldProduct, currentUser } = useApp();
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    customerId: '',
    productId: '',
    price: '',
    date: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.confirm('Satış kaydını onaylıyor musunuz?')) return;

    addSoldProduct({
      customerId: formData.customerId,
      productId: formData.productId,
      price: Number(formData.price),
      date: formData.date,
      technicianId: currentUser?.id || '1'
    });

    setShowAddModal(false);
    setFormData({ customerId: '', productId: '', price: '', date: new Date().toISOString().split('T')[0] });
    alert('Satış başarıyla kaydedildi.');
  };

  const handleProductSelect = (id: string) => {
    const product = products.find(p => p.id === id);
    setFormData({ ...formData, productId: id, price: product ? product.price.toString() : '' });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      {/* Header */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm">
        <div className="p-4 border-b border-[#f2f2f2] flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#32363a]">Satış Kayıtları</h2>
          <button 
            onClick={() => setShowAddModal(true)}
            className="px-4 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
          >
            Yeni Satış Gir
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sales List */}
        <div className="lg:col-span-8 space-y-3">
          {soldProducts.length === 0 ? (
            <div className="bg-white border border-[#d9d9d9] border-dashed p-12 text-center text-[#6a6d70] italic">
               Henüz kaydedilmiş satış bulunmuyor.
            </div>
          ) : (
            [...soldProducts].reverse().map((sale) => {
              const customer = customers.find(c => c.id === sale.customerId);
              const product = products.find(p => p.id === sale.productId);
              
              return (
                <div key={sale.id} className="bg-white border border-[#d9d9d9] p-4 flex items-center justify-between hover:border-[#0070b4] transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#f5f9fc] text-[#0070b4] flex items-center justify-center border border-[#d9d9d9]">
                       <Tag size={20} />
                    </div>
                    <div>
                       <p className="font-bold text-[#32363a]">{product?.name || 'Bilinmeyen Ürün'}</p>
                       <p className="text-xs text-[#6a6d70]">Müşteri: {customer?.firstName} {customer?.lastName} • {new Date(sale.date).toLocaleDateString('tr-TR')}</p>
                    </div>
                  </div>
                  <div className="text-right">
                     <p className="text-sm font-bold text-[#0070b4]">{sale.price.toLocaleString('tr-TR')} TL</p>
                     <span className="text-[10px] font-bold text-emerald-600 uppercase">Tahsil Edildi</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sales Summary Widget */}
        <div className="lg:col-span-4">
           <section className="bg-[#354a5f] text-white p-6 shadow-md border-b-4 border-[#0070b4]">
              <div className="flex items-center gap-2 mb-6 opacity-80">
                 <TrendingUp size={18} />
                 <h3 className="text-xs font-bold uppercase tracking-widest">Satış Özeti</h3>
              </div>
              <div className="space-y-4">
                 <div>
                    <p className="text-[10px] uppercase text-blue-200 font-bold mb-1">Toplam Ciro</p>
                    <p className="text-2xl font-light">
                      {soldProducts.reduce((acc, s) => acc + s.price, 0).toLocaleString('tr-TR')} TL
                    </p>
                 </div>
                 <div className="h-[1px] bg-white/10"></div>
                 <div>
                    <p className="text-[10px] uppercase text-blue-200 font-bold mb-1">Satış Adedi</p>
                    <p className="text-xl font-light">{soldProducts.length} İşlem</p>
                 </div>
              </div>
           </section>
        </div>
      </div>

      {/* Add Sale Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-[1px]" onClick={() => setShowAddModal(false)} />
          <div className="bg-white border border-[#d9d9d9] w-full max-w-md relative z-[101] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider">Satış Kaydı Oluştur</h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#6a6d70] p-1"><Plus className="rotate-45" size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70] uppercase">Müşteri Seçin</label>
                <div className="relative">
                   <User className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={14} />
                   <select 
                     required
                     className="w-full pl-9 pr-3 py-2 bg-white border border-[#d9d9d9] outline-none focus:border-[#0070b4]"
                     value={formData.customerId}
                     onChange={e => setFormData({...formData, customerId: e.target.value})}
                   >
                     <option value="">Seçiniz...</option>
                     {customers.map(c => <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>)}
                   </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70] uppercase">Satılan Ürün</label>
                <div className="relative">
                   <ShoppingCart className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={14} />
                   <select 
                     required
                     className="w-full pl-9 pr-3 py-2 bg-white border border-[#d9d9d9] outline-none focus:border-[#0070b4]"
                     value={formData.productId}
                     onChange={e => handleProductSelect(e.target.value)}
                   >
                     <option value="">Seçiniz...</option>
                     {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                   </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6a6d70] uppercase">Satış Fiyatı (TL)</label>
                  <input required type="number" className="w-full px-3 py-2 border border-[#d9d9d9] outline-none focus:border-[#0070b4]" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6a6d70] uppercase">Tarih</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={14} />
                    <input required type="date" className="w-full pl-9 pr-3 py-2 border border-[#d9d9d9] outline-none" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
                  </div>
                </div>
              </div>

              <div className="flex gap-2 justify-end pt-4 border-t border-[#f2f2f2]">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-6 py-1.5 text-xs font-bold text-[#32363a] hover:bg-[#f2f2f2]">İptal</button>
                <button type="submit" className="px-6 py-1.5 bg-[#0070b4] text-white text-xs font-bold border border-[#0070b4] hover:bg-[#005a92]">Kaydet</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default SoldProducts;
