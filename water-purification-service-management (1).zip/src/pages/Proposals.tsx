import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Trash2, 
  FileText, 
  ShoppingCart,
  Calculator
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product, ProposalItem } from '../types';
import { generateProposalPDF } from '../utils/pdfGenerator';

const PREDEFINED_PRODUCTS: Product[] = [
  { id: 'p1', name: '5 Aşamalı Eco Su Arıtma Cihazı', price: 4250, category: 'Cihaz' },
  { id: 'p2', name: '7 Aşamalı Alkali Pro Su Arıtma', price: 5800, category: 'Cihaz' },
  { id: 'p3', name: 'Pompalı Kapalı Kasa Arıtma', price: 6500, category: 'Cihaz' },
  { id: 'p4', name: 'Yıllık Periyodik Bakım Paketi', price: 1250, category: 'Servis' },
  { id: 'p5', name: 'Standart 3\'lü Filtre Seti', price: 450, category: 'Yedek Parça' },
  { id: 'p6', name: '80 GPD Membran Filtre', price: 950, category: 'Yedek Parça' },
  { id: 'p7', name: 'Mineral + Alkali Filtre Takımı', price: 850, category: 'Yedek Parça' },
  { id: 'p8', name: 'Daire Girişi Kireç Önleyici Sistem', price: 3200, category: 'Cihaz' },
];

const Proposals: React.FC = () => {
  const { products } = useApp();
  const [selectedItems, setSelectedItems] = useState<ProposalItem[]>([]);
  const [proposalNotes, setProposalNotes] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);

  const subtotal = useMemo(() => {
    return selectedItems.reduce((acc, item) => acc + (item.unitPrice * item.quantity), 0);
  }, [selectedItems]);

  const discountAmount = subtotal * (discountPercent / 100);
  const afterDiscount = subtotal - discountAmount;
  const vat = afterDiscount * 0.20;
  const total = afterDiscount + vat;

  const handleAddItem = (product: Product) => {
    setSelectedItems(prev => {
      const existing = prev.find(i => i.productId === product.id);
      if (existing) {
        return prev.map(i => i.productId === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { productId: product.id, quantity: 1, unitPrice: product.price }];
    });
  };

  const handleRemoveItem = (productId: string) => {
    setSelectedItems(prev => prev.filter(i => i.productId !== productId));
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setSelectedItems(prev => prev.map(i => {
      if (i.productId === productId) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty };
      }
      return i;
    }));
  };

  const handleGeneratePDF = () => {
    if (selectedItems.length === 0) {
      alert('Hata: Teklif listesi boş!');
      return;
    }

    const isConfirmed = window.confirm(
      `Toplam ${total.toLocaleString('tr-TR')} TL tutarında teklif oluşturulacak ve PDF dosyası indirilecektir. Onaylıyor musunuz?`
    );

    if (isConfirmed) {
      generateProposalPDF(
        { firstName: 'Teknik Servis', lastName: 'Müşteri Teklifi', tcNumber: '-', phone: '-', address: '-', id: 'TEK-1', notes: '', createdAt: new Date().toISOString() }, 
        selectedItems, 
        products, 
        { subtotal, vat, total, discountAmount, discountPercent }, 
        proposalNotes
      );
    }
  };

  return (
    <div className="-m-4 lg:-m-8">
      {/* Fiori Header */}
      <header className="bg-white border-b border-[#d9d9d9] px-4 md:px-8 py-6 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-bold text-[#0070b4] mb-2 uppercase tracking-wider">
               <FileText size={12} /> Teklif Yönetimi
            </div>
            <h2 className="text-2xl font-light text-[#32363a]">Yeni Teklif Oluştur</h2>
          </div>
          <div className="flex gap-2">
             <button 
               onClick={() => { setSelectedItems([]); }}
               className="px-6 py-2 bg-white text-[#32363a] text-sm font-bold border border-[#d9d9d9] hover:bg-[#f2f2f2]"
             >
               Temizle
             </button>
             <button 
               onClick={handleGeneratePDF}
               className="px-6 py-2 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
             >
               PDF Olarak Kaydet
             </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-3 sm:p-4 md:p-8 flex flex-col lg:flex-row gap-6 sm:gap-8 pb-24">
        
        {/* Selection Area */}
        <div className="flex-1 space-y-6">
          <section className="bg-white border border-[#d9d9d9] shadow-sm">
            <div className="px-4 sm:px-6 py-3 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center justify-between">
              <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider flex items-center gap-2">
                <ShoppingCart size={16} className="text-[#0070b4]" /> Ürün Seçimi
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-0 divide-y sm:divide-y-0 divide-[#f2f2f2]">
               {products.map((product) => (
                 <div key={product.id} className="p-4 hover:bg-[#f5f9fc] transition-colors flex flex-col justify-between border-b sm:border-r border-[#f2f2f2]">
                    <div className="mb-3">
                       <span className="text-[9px] font-bold bg-[#f2f2f2] text-[#6a6d70] px-1.5 py-0.5 uppercase tracking-widest">{product.category}</span>
                       <h4 className="text-sm font-bold text-[#32363a] mt-1">{product.name}</h4>
                       <p className="text-sm font-light text-[#0070b4] mt-1">{product.price.toLocaleString('tr-TR')} TL</p>
                    </div>
                    <button 
                      onClick={() => handleAddItem(product)}
                      className="w-full py-2.5 sm:py-1.5 border border-[#0070b4] text-[#0070b4] text-xs font-bold active:bg-[#0070b4] active:text-white sm:hover:bg-[#0070b4] sm:hover:text-white transition-all flex items-center justify-center gap-2"
                    >
                      <Plus size={14} /> Ekle
                    </button>
                 </div>
               ))}
            </div>
          </section>
        </div>

        {/* Configuration Area */}
        <div className="lg:w-[400px] space-y-6">
          <section className="bg-white border border-[#d9d9d9] p-5 sm:p-6 shadow-sm">
            <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider border-b border-[#f2f2f2] pb-3 mb-4 flex items-center gap-2">
              <Calculator size={16} className="text-[#6a6d70]" /> İskonto (%)
            </h3>
            <div className="flex items-center gap-3">
               <input 
                 type="number"
                 placeholder="0"
                 className="flex-1 px-4 py-3 sm:py-2 bg-[#f7f7f7] border border-[#d9d9d9] text-sm outline-none focus:border-[#0070b4]"
                 value={discountPercent || ''}
                 onChange={(e) => setDiscountPercent(Number(e.target.value))}
               />
               <span className="text-xs font-bold text-[#6a6d70]">İndirim</span>
            </div>
          </section>

          {/* Cart / Selected Items */}
          <section className="bg-white border border-[#d9d9d9] shadow-sm">
            <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
              <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider">Teklif İçeriği</h3>
            </div>
            <div className="divide-y divide-[#f2f2f2] max-h-[300px] overflow-y-auto">
              {selectedItems.length === 0 ? (
                <div className="p-10 text-center text-[#6a6d70] text-xs italic">Teklif henüz boş. Ürün ekleyin.</div>
              ) : (
                selectedItems.map((item) => {
                  const product = PREDEFINED_PRODUCTS.find(p => p.id === item.productId);
                  return (
                    <div key={item.productId} className="p-4 flex items-center justify-between group">
                      <div className="flex-1">
                        <p className="text-sm font-bold text-[#32363a]">{product?.name}</p>
                        <p className="text-xs text-[#6a6d70]">{item.unitPrice.toLocaleString('tr-TR')} TL x {item.quantity}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center border border-[#d9d9d9] bg-white">
                           <button 
                             onClick={() => handleUpdateQuantity(item.productId, -1)} 
                             className="w-10 h-10 bg-[#f2f2f2] active:bg-[#d9d9d9] flex items-center justify-center font-bold"
                           >
                             -
                           </button>
                           <span className="px-4 text-sm font-bold min-w-[40px] text-center">{item.quantity}</span>
                           <button 
                             onClick={() => handleUpdateQuantity(item.productId, 1)} 
                             className="w-10 h-10 bg-[#f2f2f2] active:bg-[#d9d9d9] flex items-center justify-center font-bold"
                           >
                             +
                           </button>
                        </div>
                        <button 
                          onClick={() => handleRemoveItem(item.productId)}
                          className="text-[#bb0000] opacity-0 group-hover:opacity-100 transition-opacity p-1"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* Totals */}
          <section className="bg-[#354a5f] text-white p-6 shadow-md">
             <div className="flex items-center gap-2 mb-6 border-b border-white/10 pb-4">
                <Calculator size={18} />
                <h3 className="text-xs font-bold uppercase tracking-widest">Hesap Özeti</h3>
             </div>
             <div className="space-y-3">
                <div className="flex justify-between text-sm opacity-80">
                   <span>Ara Toplam</span>
                   <span>{subtotal.toLocaleString('tr-TR')} TL</span>
                </div>
                <div className="flex justify-between text-sm opacity-80">
                   <span>KDV (%20)</span>
                   <span>{vat.toLocaleString('tr-TR')} TL</span>
                </div>
                <div className="h-[1px] bg-white/10 my-2"></div>
                <div className="flex justify-between text-lg font-bold">
                   <span>GENEL TOPLAM</span>
                   <span className="text-blue-300">{total.toLocaleString('tr-TR')} TL</span>
                </div>
             </div>
             
             <div className="mt-8 space-y-2">
                <label className="text-[10px] font-bold uppercase text-blue-200">Teklif Notu (Ödeme Koşulları vb.)</label>
                <textarea 
                  className="w-full bg-white/5 border border-white/20 rounded-sm p-3 text-xs outline-none focus:border-blue-400 min-h-[80px]"
                  placeholder="Örn: %50 Peşin, kalan 3 taksit..."
                  value={proposalNotes}
                  onChange={(e) => setProposalNotes(e.target.value)}
                />
             </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Proposals;
