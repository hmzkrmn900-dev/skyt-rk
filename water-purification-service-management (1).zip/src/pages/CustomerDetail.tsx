import React, { useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Smartphone, 
  MapPin, 
  Phone, 
  Plus, 
  ChevronRight,
  History,
  Camera,
  X,
  User
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useApp } from '../context/AppContext';

const CustomerDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getCustomer, devices, addDevice, updateCustomer } = useApp();
  const customer = getCustomer(id || '');
  
  const [showAddDevice, setShowAddDevice] = useState(false);
  const [isEditingNote, setIsEditingNote] = useState(false);
  const [noteText, setNoteText] = useState(customer?.notes || '');
  const [newDevice, setNewDevice] = useState({
    brand: 'AquaSoft',
    model: '',
    serialNumber: '',
    installationDate: new Date().toISOString().split('T')[0],
    warrantyUntil: new Date(new Date().setFullYear(new Date().getFullYear() + 2)).toISOString().split('T')[0],
  });

  const customerDevices = devices.filter(d => d.customerId === id);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!customer) {
    return (
      <div className="p-12 bg-white border border-[#d9d9d9] text-center space-y-4">
        <div className="w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto">
          <User size={32} />
        </div>
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-[#32363a]">Müşteri Bulunamadı</h2>
          <p className="text-sm text-[#6a6d70]">İstediğiniz ID ({id}) ile eşleşen bir kayıt sistemde mevcut değil.</p>
        </div>
        <Link 
          to="/customers" 
          className="inline-block px-6 py-2 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
        >
          Müşteri Listesine Dön
        </Link>
      </div>
    );
  }

  const handleAddDevice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.confirm('Yeni cihaz kaydı oluşturulacaktır. Onaylıyor musunuz?')) return;

    addDevice({
      ...newDevice,
      customerId: customer.id,
      filters: [
        { name: 'Sediment Filtre', lastChanged: newDevice.installationDate, nextChange: '', status: 'good' },
        { name: 'GAC Karbon', lastChanged: newDevice.installationDate, nextChange: '', status: 'good' },
        { name: 'Blok Karbon', lastChanged: newDevice.installationDate, nextChange: '', status: 'good' }
      ]
    });
    setShowAddDevice(false);
    alert('Cihaz başarıyla tanımlandı.');
  };

  const handleSaveNote = () => {
    updateCustomer({ ...customer, notes: noteText });
    setIsEditingNote(false);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const photos = customer.notePhotos || [];
        updateCustomer({ ...customer, notePhotos: [...photos, reader.result as string] });
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = (index: number) => {
    if (!confirm('Görseli silmek istiyor musunuz?')) return;
    const photos = [...(customer.notePhotos || [])];
    photos.splice(index, 1);
    updateCustomer({ ...customer, notePhotos: photos });
  };

  return (
    <div className="-m-4 lg:-m-8">
      {/* Fiori Object Page Header */}
      <header className="bg-white border-b border-[#d9d9d9] px-4 md:px-8 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 text-[11px] font-bold text-[#0070b4] mb-4 uppercase tracking-wider">
            <Link to="/customers" className="hover:underline">Müşteriler</Link>
            <ChevronRight size={12} />
            <span className="text-[#6a6d70]">Detay</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 bg-[#f2f2f2] border border-[#d9d9d9] flex items-center justify-center text-[#0070b4] text-3xl font-light">
                {customer.firstName[0]}{customer.lastName[0]}
              </div>
              <div className="space-y-1">
                <h2 className="text-2xl font-light text-[#32363a]">{customer.firstName} {customer.lastName}</h2>
                <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                   <div className="flex items-center gap-2 text-[#6a6d70]">
                      <span className="font-bold text-[10px] uppercase bg-[#f2f2f2] px-1.5 py-0.5 border border-[#d9d9d9]">TC: {customer.tcNumber}</span>
                   </div>
                   <div className="flex items-center gap-2 text-[#6a6d70]">
                      <Phone size={14} /> {customer.phone}
                   </div>
                   <div className="flex items-center gap-2 text-[#6a6d70]">
                      <MapPin size={14} /> {customer.address}
                   </div>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92] transition-colors">
                Düzenle
              </button>
              <button className="px-4 py-1.5 bg-white text-[#bb0000] text-sm font-bold border border-[#bb0000] hover:bg-[#bb0000] hover:text-white transition-colors">
                Sil
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Fiori Object Page Content (Facets) */}
      <div className="max-w-7xl mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-8">
          <section>
            <div className="flex items-center justify-between mb-4 border-b border-[#d9d9d9] pb-2">
              <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider flex items-center gap-2">
                <Smartphone size={16} className="text-[#0070b4]" />
                Cihazlar ({customerDevices.length})
              </h3>
              <button 
                onClick={() => setShowAddDevice(true)}
                className="text-xs font-bold text-[#0070b4] hover:underline flex items-center gap-1"
              >
                <Plus size={14} /> Yeni Cihaz Tanımla
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {customerDevices.map((device) => (
                <Link 
                  key={device.id} 
                  to={`/devices/${device.id}`}
                  className="bg-white border border-[#d9d9d9] p-5 hover:border-[#0070b4] transition-all group relative overflow-hidden"
                >
                  <div className="flex justify-between mb-4">
                    <div className="p-2 bg-[#f2f2f2] group-hover:bg-[#0070b4] group-hover:text-white transition-colors">
                        <Smartphone size={20} />
                    </div>
                    <span className="text-[10px] font-bold text-[#6a6d70] bg-[#f2f2f2] px-1.5 py-0.5 h-fit">{device.id}</span>
                  </div>
                  <h4 className="font-bold text-[#32363a]">{device.brand} {device.model}</h4>
                  <p className="text-xs text-[#6a6d70] mt-1 italic">Seri: {device.serialNumber}</p>
                  <div className="mt-4 pt-4 border-t border-[#f2f2f2] flex justify-between items-center text-[11px]">
                    <span className="text-[#6a6d70]">Garanti: {new Date(device.warrantyUntil).toLocaleDateString('tr-TR')}</span>
                    <ChevronRight size={14} className="text-[#0070b4]" />
                  </div>
                </Link>
              ))}
              {customerDevices.length === 0 && (
                <div className="col-span-full py-12 bg-white border border-[#d9d9d9] border-dashed text-center text-[#6a6d70] text-sm italic">
                  Bu müşteriye kayıtlı cihaz bulunmamaktadır.
                </div>
              )}
            </div>
          </section>

          <section className="bg-white border border-[#d9d9d9] p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6 border-b border-[#f2f2f2] pb-4">
              <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider flex items-center gap-2">
                  <History size={16} className="text-[#6a6d70]" />
                  Müşteri Notları & Görseller
              </h3>
              <div className="flex gap-2">
                <button 
                  onClick={() => setIsEditingNote(!isEditingNote)}
                  className="text-xs font-bold text-[#32363a] hover:bg-[#f2f2f2] px-3 py-1.5 border border-[#d9d9d9]"
                >
                  {isEditingNote ? 'Vazgeç' : 'Notu Düzenle'}
                </button>
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs font-bold text-[#0070b4] hover:bg-[#f2f2f2] px-3 py-1.5 border border-[#d9d9d9] flex items-center gap-2"
                >
                  <Camera size={14} /> Görsel Yükle
                </button>
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
            </div>
            
            <div className="space-y-6">
                {isEditingNote ? (
                  <div className="space-y-3">
                    <textarea 
                      className="w-full p-3 border border-[#0070b4] text-sm outline-none bg-slate-50 min-h-[100px]"
                      value={noteText}
                      onChange={(e) => setNoteText(e.target.value)}
                      placeholder="Notunuzu buraya yazın..."
                    />
                    <button onClick={handleSaveNote} className="px-6 py-2 bg-[#0070b4] text-white text-xs font-bold shadow-md">Kaydet</button>
                  </div>
                ) : (
                  customer.notes ? (
                    <div className="p-4 bg-[#fdfaf2] border-l-4 border-[#e9730c] text-sm text-[#32363a] whitespace-pre-wrap">
                      {customer.notes}
                    </div>
                  ) : (
                    <p className="text-sm text-[#6a6d70] italic">Herhangi bir not bulunmuyor.</p>
                  )
                )}

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                  {customer.notePhotos?.map((photo, idx) => (
                    <div key={idx} className="group relative aspect-square bg-slate-100 border border-[#d9d9d9] overflow-hidden rounded-sm">
                      <img src={photo} alt="" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button onClick={() => removePhoto(idx)} className="p-2 bg-white/20 hover:bg-red-500 text-white transition-colors">
                           <X size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                  {(!customer.notePhotos || customer.notePhotos.length === 0) && !isEditingNote && (
                    <div className="col-span-full py-8 text-center border-2 border-dashed border-[#f2f2f2] text-[#d9d9d9]">
                       <Camera size={40} className="mx-auto opacity-20" />
                       <p className="text-xs mt-2 font-bold uppercase tracking-widest">Görsel Kaydı Yok</p>
                    </div>
                  )}
                </div>
            </div>
          </section>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <section className="bg-white border border-[#d9d9d9] p-6 text-center flex flex-col items-center shadow-sm">
            <div className="p-3 bg-white border border-[#d9d9d9] mb-4">
                <QRCodeSVG value={`${window.location.origin}/customers/${customer.id}`} size={160} level="M" />
            </div>
            <h4 className="text-xs font-bold text-[#32363a] uppercase tracking-wider mb-2">Müşteri QR Kodu</h4>
            <p className="text-[10px] text-[#6a6d70] leading-relaxed mb-4">
              Bu kod müşterinin dosyasında veya sisteminde bulunmalıdır. Okutulduğunda doğrudan bu sayfaya yönlendirir.
            </p>
            <button className="w-full py-2 bg-[#f2f2f2] text-[#0070b4] text-xs font-bold border border-[#d9d9d9] hover:bg-[#ebebeb] flex items-center justify-center gap-2">
               Müşteri Kartı Yazdır
            </button>
          </section>

          <section className="bg-white border border-[#d9d9d9] p-4 space-y-3 shadow-sm">
             <div className="flex items-center gap-2 text-[#0070b4] border-b border-[#f2f2f2] pb-2 mb-2">
                <User size={16} />
                <span className="text-xs font-bold uppercase tracking-wider">Hızlı Erişim</span>
             </div>
             <div className="space-y-2">
                <button className="w-full text-left text-xs p-2 hover:bg-[#f5f9fc] text-[#32363a] flex items-center justify-between border border-transparent hover:border-[#0070b4] transition-all">
                   Servis Geçmişini İndir <ChevronRight size={12} />
                </button>
                <button className="w-full text-left text-xs p-2 hover:bg-[#f5f9fc] text-[#32363a] flex items-center justify-between border border-transparent hover:border-[#0070b4] transition-all">
                   Konumu Haritada Gör <MapPin size={12} />
                </button>
             </div>
          </section>
        </div>
      </div>

      {/* Add Device Modal */}
      {showAddDevice && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setShowAddDevice(false)} />
          <div className="bg-white rounded-3xl w-full max-w-lg relative z-[101] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-xl font-bold text-slate-900">Yeni Cihaz Tanımla</h3>
              <button onClick={() => setShowAddDevice(false)} className="text-slate-400 hover:text-slate-600 p-2">
                <Plus className="rotate-45" size={24} />
              </button>
            </div>
            <form onSubmit={handleAddDevice} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Marka</label>
                  <input 
                    required
                    type="text" 
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                    value={newDevice.brand}
                    onChange={e => setNewDevice({...newDevice, brand: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Model</label>
                  <input 
                    required
                    type="text" 
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                    value={newDevice.model}
                    onChange={e => setNewDevice({...newDevice, model: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-slate-700">Seri Numarası (S/N)</label>
                <input 
                  required
                  type="text" 
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  value={newDevice.serialNumber}
                  onChange={e => setNewDevice({...newDevice, serialNumber: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Montaj Tarihi</label>
                  <input 
                    required
                    type="date" 
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20"
                    value={newDevice.installationDate}
                    onChange={e => setNewDevice({...newDevice, installationDate: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Garanti Bitiş</label>
                  <input 
                    required
                    type="date" 
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20"
                    value={newDevice.warrantyUntil}
                    onChange={e => setNewDevice({...newDevice, warrantyUntil: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex gap-3 pt-6">
                <button 
                  type="button"
                  onClick={() => setShowAddDevice(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                >
                  İptal
                </button>
                <button 
                  type="submit"
                  className="flex-[2] px-4 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
                >
                  Cihazı Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDetail;
