import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Smartphone, Lock, Mail, ArrowRight, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Login: React.FC = () => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(userId, password);
    if (success) {
      navigate('/');
    } else {
      setError('Hatalı Giriş Bilgileri!');
    }
  };

  return (
    <div className="min-h-screen bg-[#edeff0] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white border border-[#d9d9d9] shadow-2xl overflow-hidden">
        <div className="p-8 text-center bg-[#354a5f] text-white border-b-4 border-[#0070b4]">
          <div className="inline-flex p-3 bg-white/10 rounded-lg mb-4">
            <Smartphone size={32} />
          </div>
          <h1 className="text-xl font-bold uppercase tracking-widest">SuArıtma CRM</h1>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="p-3 bg-red-50 border-l-4 border-red-500 text-red-700 text-xs font-bold">
              {error}
            </div>
          )}
          <div className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#6a6d70] uppercase">Kullanıcı No (Giriş)</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={16} />
                <input 
                  required
                  type="text"
                  placeholder="555024xxxx"
                  className="w-full pl-10 pr-4 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none transition-all text-[#32363a]"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#6a6d70] uppercase">Giriş Şifresi</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={16} />
                <input 
                  required
                  type="password"
                  placeholder="••••••"
                  className="w-full pl-10 pr-4 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none transition-all text-[#32363a]"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
              <input type="checkbox" className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
              Beni Hatırla
            </label>
            <button type="button" className="text-blue-600 font-bold hover:underline">Şifremi Unuttum</button>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center gap-2 group"
          >
            Giriş Yap
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>

          <div className="pt-6 border-t border-slate-100 flex items-center justify-center gap-2 text-slate-400 text-xs">
            <ShieldCheck size={14} />
            Güvenli Bağlantı Aktif
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
