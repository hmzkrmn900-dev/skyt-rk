import React, { useState } from 'react';
import { 
  Trash2, 
  Edit, 
  Search,
  X
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';

const Catalog: React.FC = () => {
  const { products, addProduct, updateProduct, deleteProduct } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: 'Cihaz'
  });

  const filtered = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      name: formData.name,
      price: Number(formData.price),
      category: formData.category
    };

    if (editingProduct) {
      updateProduct({ ...data, id: editingProduct.id });
    } else {
      addProduct(data);
    }
    
    handleClose();
  };

  const handleEdit = (p: Product) => {
    setEditingProduct(p);
    setFormData({
      name: p.name,
      price: p.price.toString(),
      category: p.category
    });
    setShowModal(true);
  };

  const handleClose = () => {
    setShowModal(false);
    setEditingProduct(null);
    setFormData({ name: '', price: '', category: 'Cihaz' });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      {/* Fiori List Report Header */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm">
        <div className="p-4 border-b border-[#f2f2f2] flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#32363a]">Ürün Kataloğu Yönetimi</h2>
          <button 
            onClick={() => setShowModal(true)}
            className="px-4 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
          >
            Yeni Ürün Ekle
          </button>
        </div>
        
        <div className="p-4 bg-[#f7f7f7]">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={16} />
            <input 
              type="text" 
              placeholder="Ürün Ara..."
              className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Product List / Mobile Enhanced */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm overflow-hidden">
        {/* Desktop View */}
        <table className="w-full text-left text-sm hidden md:table">
          <thead>
            <tr className="border-b border-[#d9d9d9] bg-[#f7f7f7]">
              <th className="px-6 py-3 font-bold text-[#32363a]">Ürün / Hizmet Adı</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">Kategori</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">Birim Fiyat</th>
              <th className="px-6 py-3 font-bold text-[#32363a] text-right">İşlem</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#f2f2f2]">
            {filtered.map((p) => (
              <tr key={p.id} className="hover:bg-[#f5f9fc] transition-colors">
                <td className="px-6 py-4 font-bold text-[#0070b4]">{p.name}</td>
                <td className="px-6 py-4 text-[#6a6d70] text-xs font-bold uppercase">{p.category}</td>
                <td className="px-6 py-4 font-bold">{p.price.toLocaleString('tr-TR')} TL</td>
                <td className="px-6 py-4 text-right space-x-2">
                  <button onClick={() => handleEdit(p)} className="text-[#0070b4] font-bold hover:underline">Düzenle</button>
                  <button onClick={() => { if(confirm('Silmek istediğinize emin misiniz?')) deleteProduct(p.id) }} className="text-[#bb0000] font-bold hover:underline">Sil</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Mobile View - Touch Enhanced */}
        <div className="md:hidden divide-y divide-[#f2f2f2]">
          {filtered.map((p) => (
            <div key={p.id} className="p-4 flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                   <p className="text-[10px] font-bold text-[#6a6d70] uppercase mb-0.5">{p.category}</p>
                   <h4 className="font-bold text-[#32363a] leading-tight">{p.name}</h4>
                   <p className="text-[#0070b4] font-bold mt-1">{p.price.toLocaleString('tr-TR')} TL</p>
                </div>
              </div>
              <div className="flex gap-2 border-t border-[#f7f7f7] pt-3">
                 <button 
                   onClick={() => handleEdit(p)}
                   className="flex-1 py-2.5 bg-[#f2f2f2] text-[#32363a] text-xs font-bold flex items-center justify-center gap-2 active:bg-[#d9d9d9]"
                 >
                   <Edit size={14} /> Düzenle
                 </button>
                 <button 
                   onClick={() => { if(confirm('Silinsin mi?')) deleteProduct(p.id) }}
                   className="flex-1 py-2.5 bg-[#bb0000]/10 text-[#bb0000] text-xs font-bold flex items-center justify-center gap-2 active:bg-[#bb0000]/20"
                 >
                   <Trash2 size={14} /> Sil
                 </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-[1px]" onClick={handleClose} />
          <div className="bg-white border border-[#d9d9d9] w-full max-w-md relative z-[101] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider">
                {editingProduct ? 'Ürün Düzenle' : 'Yeni Ürün Ekle'}
              </h3>
              <button onClick={handleClose} className="text-[#6a6d70] hover:text-[#32363a]">
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70]">Ürün Adı</label>
                <input required type="text" className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70]">Kategori</label>
                <select className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                   <option value="Cihaz">Cihaz</option>
                   <option value="Servis">Servis</option>
                   <option value="Yedek Parça">Yedek Parça</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#6a6d70]">Birim Fiyat (TL)</label>
                <input required type="number" className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
              </div>
              
              <div className="flex gap-2 justify-end pt-4 border-t border-[#f2f2f2]">
                <button type="button" onClick={handleClose} className="px-6 py-1.5 text-xs font-bold text-[#32363a] hover:bg-[#f2f2f2]">İptal</button>
                <button type="submit" className="px-6 py-1.5 bg-[#0070b4] text-white text-xs font-bold border border-[#0070b4] hover:bg-[#005a92]">Kaydet</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Catalog;
