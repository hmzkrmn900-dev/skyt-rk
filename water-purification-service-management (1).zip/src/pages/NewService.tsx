import React, { useState, useRef } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { 
  CheckSquare, 
  ChevronRight
} from 'lucide-react';
import SignatureCanvas from 'react-signature-canvas';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

const NewService: React.FC = () => {
  const [searchParams] = useSearchParams();
  const deviceId = searchParams.get('deviceId');
  const navigate = useNavigate();
  const { getDevice, addService, currentUser, updateDevice } = useApp();
  const sigPad = useRef<any>(null);

  const device = getDevice(deviceId || '');

  const [newOperation, setNewOperation] = useState('');
  const [formData, setFormData] = useState({
    type: 'MAINTENANCE' as const,
    tdsIn: '',
    tdsOut: '',
    pressure: '',
    operations: [] as string[],
    notes: '',
    totalAmount: '',
    paymentStatus: 'PAID' as const,
    paymentMethod: 'CASH' as const
  });

  const [operationOptions, setOperationOptions] = useState([
    'Sediment Filtre Değişimi',
    'Karbon Filtre Değişimi',
    'Membran Filtre Değişimi',
    'Post Karbon Filtre Değişimi',
    'Sızdırmazlık Testi',
    'Tank Basınç Kontrolü'
  ]);

  const handleAddOperation = () => {
    if (newOperation.trim()) {
      setOperationOptions([...operationOptions, newOperation.trim()]);
      setFormData(prev => ({ ...prev, operations: [...prev.operations, newOperation.trim()] }));
      setNewOperation('');
    }
  };

  const handleToggleOperation = (op: string) => {
    setFormData(prev => ({
      ...prev,
      operations: prev.operations.includes(op)
        ? prev.operations.filter(i => i !== op)
        : [...prev.operations, op]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!device) return;

    const signature = sigPad.current?.getTrimmedCanvas().toDataURL('image/png') || '';

    addService({
      deviceId: device.id,
      technicianId: currentUser?.id || '1',
      date: new Date().toISOString(),
      type: formData.type,
      tdsIn: Number(formData.tdsIn),
      tdsOut: Number(formData.tdsOut),
      pressure: Number(formData.pressure),
      operations: formData.operations,
      partsChanged: [],
      notes: formData.notes,
      photoUrls: [],
      customerSignature: signature,
      totalAmount: Number(formData.totalAmount),
      paymentStatus: formData.paymentStatus,
      paymentMethod: formData.paymentMethod
    });

    // Automatically update filter status if "Filtre Değişimi" is selected
    if (formData.operations.some(op => op.includes('Değişimi'))) {
      const updatedFilters = device.filters.map(f => {
        // Simple logic: if operation includes filter name, it's changed
        const isChanged = formData.operations.some(op => op.includes(f.name.split(' ')[0]));
        if (isChanged) {
           // Calculate next change (approx 6 months later)
           const next = new Date();
           next.setMonth(next.getMonth() + 6);
           return { 
             ...f, 
             lastChanged: new Date().toISOString().split('T')[0], 
             nextChange: next.toISOString().split('T')[0],
             status: 'good' as const 
           };
        }
        return f;
      });
      updateDevice({ ...device, filters: updatedFilters });
    }

    alert('Servis kaydı başarıyla oluşturuldu.');
    navigate(`/devices/${device.id}`);
  };

  if (!device) return <div className="p-8 text-center text-[#6a6d70]">Cihaz seçilmedi.</div>;

  return (
    <div className="-m-4 lg:-m-8">
      {/* Fiori Wizard Header */}
      <header className="bg-white border-b border-[#d9d9d9] px-4 md:px-8 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-2 text-[11px] font-bold text-[#0070b4] mb-4 uppercase tracking-wider">
            <Link to="/devices" className="hover:underline">Cihazlar</Link>
            <ChevronRight size={12} />
            <span className="text-[#6a6d70]">Yeni Servis Kaydı</span>
          </div>
          <h2 className="text-2xl font-light text-[#32363a]">Servis Formu: {device.brand} {device.model}</h2>
          <p className="text-xs text-[#6a6d70] mt-1 italic">ID: {device.id} • Seri: {device.serialNumber}</p>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto p-4 md:p-8 space-y-8 pb-24">
        {/* Operations Section */}
        <section className="bg-white border border-[#d9d9d9] shadow-sm">
          <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
             <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider">1. Yapılan İşlemler</h3>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex gap-2 mb-4">
              <input 
                type="text" 
                placeholder="Özel işlem/parça ekle..." 
                className="flex-1 px-3 py-2 border border-[#d9d9d9] text-sm outline-none focus:border-[#0070b4]"
                value={newOperation}
                onChange={(e) => setNewOperation(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddOperation())}
              />
              <button 
                type="button" 
                onClick={handleAddOperation}
                className="px-4 py-2 bg-[#f2f2f2] text-[#0070b4] text-xs font-bold border border-[#d9d9d9] hover:bg-[#ebebeb]"
              >
                İşe Ekle
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {operationOptions.map((op) => (
                <label key={op} className={cn(
                  "flex items-center gap-3 p-3 border cursor-pointer transition-colors text-sm",
                  formData.operations.includes(op) ? "bg-[#f5f9fc] border-[#0070b4] text-[#0070b4] font-bold" : "border-[#d9d9d9] text-[#6a6d70] hover:bg-[#f9f9f9]"
                )}>
                  <input 
                    type="checkbox" className="hidden"
                    checked={formData.operations.includes(op)}
                    onChange={() => handleToggleOperation(op)}
                  />
                  <div className={cn(
                    "w-4 h-4 border border-[#d9d9d9] flex items-center justify-center",
                    formData.operations.includes(op) ? "bg-[#0070b4] border-[#0070b4] text-white" : "bg-white"
                  )}>
                    {formData.operations.includes(op) && <CheckSquare size={12} />}
                  </div>
                  {op}
                </label>
              ))}
            </div>
          </div>
        </section>

        {/* Measurements */}
        <section className="bg-white border border-[#d9d9d9] shadow-sm">
          <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
             <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider">2. Ölçüm Değerleri</h3>
          </div>
          <div className="p-6 grid grid-cols-1 sm:grid-cols-3 gap-6">
             <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#6a6d70]">Giriş TDS (ppm)</label>
                <input required type="number" className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.tdsIn} onChange={e => setFormData({...formData, tdsIn: e.target.value})} />
             </div>
             <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#6a6d70]">Çıkış TDS (ppm)</label>
                <input required type="number" className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.tdsOut} onChange={e => setFormData({...formData, tdsOut: e.target.value})} />
             </div>
             <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#6a6d70]">Basınç (Bar)</label>
                <input required type="number" step="0.1" className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.pressure} onChange={e => setFormData({...formData, pressure: e.target.value})} />
             </div>
          </div>
        </section>

        {/* Finance & Notes */}
        <section className="bg-white border border-[#d9d9d9] shadow-sm">
          <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
             <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider">3. Ödeme & Notlar</h3>
          </div>
          <div className="p-6 space-y-4">
             <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#6a6d70]">Servis Bedeli (TL)</label>
                  <input required type="number" className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none font-bold" value={formData.totalAmount} onChange={e => setFormData({...formData, totalAmount: e.target.value})} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#6a6d70]">İşlem Tipi</label>
                  <select className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as any})}>
                    <option value="MAINTENANCE">Bakım</option>
                    <option value="REPAIR">Onarım</option>
                    <option value="INSTALLATION">Montaj</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#6a6d70]">Ödeme Yöntemi</label>
                  <select className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none font-bold text-[#0070b4]" value={formData.paymentMethod} onChange={e => setFormData({...formData, paymentMethod: e.target.value as any})}>
                    <option value="CASH">Nakit</option>
                    <option value="CARD">Kredi Kartı</option>
                    <option value="TRANSFER">Havale/EFT</option>
                  </select>
                </div>
             </div>
             <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#6a6d70]">Teknisyen Notları</label>
                <textarea rows={2} className="w-full px-3 py-1.5 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none resize-none" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} />
             </div>
          </div>
        </section>

        {/* Signature */}
        <section className="bg-white border border-[#d9d9d9] shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex justify-between items-center">
             <h3 className="text-xs font-bold text-[#32363a] uppercase tracking-wider">4. Müşteri Onayı</h3>
             <button type="button" onClick={() => sigPad.current?.clear()} className="text-[10px] font-bold text-[#bb0000] hover:underline uppercase tracking-widest">Temizle</button>
          </div>
          <div className="bg-slate-50 touch-none">
            <SignatureCanvas 
              ref={sigPad}
              penColor="#32363a"
              canvasProps={{ className: "w-full h-40 cursor-crosshair" }} 
            />
          </div>
        </section>

        {/* Fiori Footer Toolbar - Enhanced for Mobile */}
        <div className="fixed bottom-0 left-0 right-0 h-16 sm:h-12 bg-white border-t border-[#d9d9d9] flex items-center justify-end px-4 gap-3 z-50 shadow-[0_-4px_8px_rgba(0,0,0,0.05)]">
           <button 
             type="button" 
             onClick={() => navigate(-1)} 
             className="px-6 py-2.5 sm:py-1.5 text-sm sm:text-xs font-bold text-[#32363a] active:bg-[#f2f2f2] sm:hover:bg-[#f2f2f2]"
           >
             Vazgeç
           </button>
           <button 
             type="submit" 
             onClick={(e) => {
               if(!confirm('Servis kaydını onaylıyor musunuz?')) {
                 e.preventDefault();
               }
             }}
             className="px-8 py-2.5 sm:py-1.5 bg-[#0070b4] text-white text-sm sm:text-xs font-bold active:bg-[#005a92] sm:hover:bg-[#005a92] shadow-md"
           >
             Kaydı Onayla ve Bitir
           </button>
        </div>
      </form>
    </div>
  );
};

export default NewService;
