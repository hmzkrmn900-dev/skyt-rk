import React from 'react';
import { 
  Search, 
  Download,
  Trash2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';
import { generateServicePDF } from '../utils/pdfGenerator';

const Services: React.FC = () => {
  const { services, devices, customers, deleteService } = useApp();
  
  const getDevice = (id: string) => devices.find(d => d.id === id);
  const getCustomer = (id: string) => customers.find(c => c.id === id);

  const handleDelete = (id: string) => {
    if (confirm('Bu servis kaydını silmek istediğinize emin misiniz?')) {
      deleteService(id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      {/* Fiori List Report Header */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm">
        <div className="p-4 border-b border-[#f2f2f2] bg-[#fcfcfc]">
          <h2 className="text-lg font-bold text-[#32363a]">Servis Kayıtları ({services.length})</h2>
        </div>
        
        <div className="p-4 bg-[#f7f7f7] grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="md:col-span-2 space-y-1.5">
            <label className="text-xs font-bold text-[#6a6d70] uppercase">Müşteri veya Seri No Ara</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={16} />
              <input 
                type="text" 
                className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                placeholder="Genel arama..."
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#6a6d70] uppercase">İşlem Tipi</label>
            <select className="w-full px-3 py-1.5 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none">
              <option>Tümü</option>
              <option>Bakım</option>
              <option>Onarım</option>
              <option>Montaj</option>
            </select>
          </div>
          <button className="py-1.5 bg-[#0070b4] text-white border border-[#0070b4] text-sm font-bold hover:bg-[#005a92]">
            Filtrele
          </button>
        </div>
      </div>

      {/* Fiori Table */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm overflow-hidden text-sm">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-[#d9d9d9] bg-[#f7f7f7]">
              <th className="px-6 py-3 font-bold text-[#32363a]">Tarih / ID</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">Müşteri & Cihaz</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">İşlem Tipi</th>
              <th className="px-6 py-3 font-bold text-[#32363a] hidden sm:table-cell">Tutar</th>
              <th className="px-6 py-3 font-bold text-[#32363a] text-right">PDF</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#f2f2f2]">
            {services.map((service) => {
              const device = getDevice(service.deviceId);
              const customer = device ? getCustomer(device.customerId) : null;
              
              return (
                <tr key={service.id} className="hover:bg-[#f5f9fc] transition-colors group">
                  <td className="px-6 py-4">
                    <p className="font-bold text-[#0070b4]">{new Date(service.date).toLocaleDateString('tr-TR')}</p>
                    <p className="text-[10px] text-[#6a6d70] uppercase font-bold tracking-tighter">{service.id}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-bold text-[#32363a]">{customer?.firstName} {customer?.lastName}</p>
                    <p className="text-xs text-[#6a6d70]">{device?.brand} {device?.model}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-0.5 font-bold text-[10px] uppercase border",
                      service.type === 'MAINTENANCE' ? "bg-blue-50 text-blue-700 border-blue-200" :
                      service.type === 'REPAIR' ? "bg-amber-50 text-amber-700 border-amber-200" :
                      "bg-purple-50 text-purple-700 border-purple-200"
                    )}>
                      {service.type === 'MAINTENANCE' ? 'Bakım' : service.type === 'REPAIR' ? 'Onarım' : 'Montaj'}
                    </span>
                  </td>
                  <td className="px-6 py-4 hidden sm:table-cell">
                    <p className="font-bold text-[#32363a]">{service.totalAmount} TL</p>
                    <p className="text-[10px] text-emerald-600 font-bold">ÖDENDİ</p>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-1">
                      <button 
                        onClick={() => device && customer && generateServicePDF(service, device, customer)}
                        className="p-2 text-[#0070b4] hover:bg-[#f2f2f2] rounded transition-colors"
                        title="PDF İndir"
                      >
                        <Download size={18} />
                      </button>
                      <button 
                        onClick={() => handleDelete(service.id)}
                        className="p-2 text-[#bb0000] hover:bg-red-50 rounded transition-colors"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {services.length === 0 && (
          <div className="p-12 text-center text-[#6a6d70] italic">
            Kayıtlı servis bulunamadı.
          </div>
        )}
      </div>
    </div>
  );
};

export default Services;
