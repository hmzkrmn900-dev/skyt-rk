import React, { useState } from 'react';
import { 
  Search, 
  ChevronRight,
  MoreVertical
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Link, useNavigate } from 'react-router-dom';

const Customers: React.FC = () => {
  const { customers, addCustomer } = useApp();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    tcNumber: '',
    firstName: '',
    lastName: '',
    phone: '',
    address: '',
    notes: ''
  });

  const filteredCustomers = customers.filter(c => 
    `${c.firstName} ${c.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone.includes(searchTerm) ||
    c.tcNumber.includes(searchTerm)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.confirm('Yeni müşteri kaydını onaylıyor musunuz?')) return;
    
    addCustomer(newCustomer);
    setShowAddModal(false);
    setNewCustomer({ tcNumber: '', firstName: '', lastName: '', phone: '', address: '', notes: '' });
    alert('Müşteri başarıyla kaydedildi.');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-4">
      {/* Fiori List Report Header & Filter Bar */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm">
        <div className="p-4 border-b border-[#f2f2f2] flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#32363a]">Müşteriler ({filteredCustomers.length})</h2>
          <button 
            onClick={() => setShowAddModal(true)}
            className="px-4 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92] transition-colors shadow-sm"
          >
            Müşteri Ekle
          </button>
        </div>
        
        <div className="p-4 bg-[#f7f7f7] grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#6a6d70] uppercase">Arama</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6d70]" size={16} />
              <input 
                type="text" 
                placeholder="İsim veya Telefon..."
                className="w-full pl-9 pr-4 py-1.5 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#6a6d70] uppercase">Durum</label>
            <select className="w-full px-3 py-1.5 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none">
              <option>Tümü</option>
              <option>Aktif</option>
              <option>Pasif</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button className="flex-1 py-1.5 bg-white border border-[#d9d9d9] text-[#0070b4] text-sm font-bold hover:bg-[#f2f2f2]">
              Filtreleri Temizle
            </button>
            <button className="flex-1 py-1.5 bg-[#0070b4] text-white border border-[#0070b4] text-sm font-bold hover:bg-[#005a92]">
              Git
            </button>
          </div>
        </div>
      </div>

      {/* Fiori Responsive Table / Mobile Cards */}
      <div className="bg-white border border-[#d9d9d9] shadow-sm overflow-hidden">
        {/* Desktop Table View */}
        <table className="w-full text-left text-sm hidden md:table">
          <thead>
            <tr className="border-b border-[#d9d9d9] bg-[#f7f7f7]">
              <th className="px-6 py-3 font-bold text-[#32363a]">Müşteri</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">İletişim</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">Adres</th>
              <th className="px-6 py-3 font-bold text-[#32363a]">Kayıt</th>
              <th className="px-6 py-3 font-bold text-[#32363a] text-right">Git</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#f2f2f2]">
            {filteredCustomers.map((customer) => (
              <tr 
                key={customer.id} 
                className="hover:bg-[#f5f9fc] transition-colors group cursor-pointer" 
                onClick={() => navigate(`/customers/${customer.id}`)}
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-[#f2f2f2] text-[#0070b4] flex items-center justify-center font-bold border border-[#d9d9d9]">
                      {customer.firstName[0]}
                    </div>
                    <Link 
                      to={`/customers/${customer.id}`}
                      className="font-bold text-[#0070b4] hover:underline"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {customer.firstName} {customer.lastName}
                    </Link>
                  </div>
                </td>
                <td className="px-6 py-4 text-[#6a6d70]">{customer.phone}</td>
                <td className="px-6 py-4 text-[#6a6d70] max-w-xs truncate">{customer.address}</td>
                <td className="px-6 py-4 text-[#6a6d70]">
                  {new Date(customer.createdAt).toLocaleDateString('tr-TR')}
                </td>
                <td className="px-6 py-4 text-right">
                  <ChevronRight size={18} className="inline text-[#0070b4]" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Mobile List View (Card Style) */}
        <div className="md:hidden divide-y divide-[#f2f2f2]">
          {filteredCustomers.length > 0 ? filteredCustomers.map((customer) => (
            <Link 
              key={customer.id} 
              to={`/customers/${customer.id}`} 
              className="p-4 flex items-center justify-between hover:bg-[#f5f9fc] active:bg-[#ebebeb] transition-colors relative z-10"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#f2f2f2] text-[#0070b4] flex items-center justify-center font-bold border border-[#d9d9d9]">
                  {customer.firstName ? customer.firstName[0] : '?'}
                </div>
                <div>
                   <p className="font-bold text-sm text-[#0070b4]">{customer.firstName} {customer.lastName}</p>
                   <p className="text-[10px] font-bold text-[#6a6d70] uppercase">TC: {customer.tcNumber}</p>
                   <p className="text-xs text-[#6a6d70]">{customer.phone}</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-[#0070b4]" />
            </Link>
          )) : (
            <div className="p-8 text-center text-[#6a6d70] italic text-sm">
              Müşteri listesi boş.
            </div>
          )}
        </div>

        {filteredCustomers.length === 0 && (
          <div className="p-12 text-center text-[#6a6d70] italic">
            Aranan kriterlere uygun müşteri bulunamadı.
          </div>
        )}
      </div>

      {/* Fiori Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-[1px]" onClick={() => setShowAddModal(false)} />
          <div className="bg-white border border-[#d9d9d9] w-full max-w-xl relative z-[101] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider">Yeni Müşteri Kaydı</h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#6a6d70] hover:text-[#32363a]">
                <MoreVertical className="rotate-45" size={20} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#6a6d70]">T.C. Kimlik No <span className="text-[#bb0000]">*</span></label>
                    <input 
                      required
                      type="text"
                      maxLength={11}
                      pattern="\d{11}"
                      placeholder="11 Haneli TC"
                      className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                      value={newCustomer.tcNumber}
                      onChange={e => setNewCustomer({...newCustomer, tcNumber: e.target.value.replace(/\D/g, '')})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#6a6d70]">Telefon <span className="text-[#bb0000]">*</span></label>
                    <input 
                      required
                      type="tel"
                      placeholder="05xx xxx xx xx"
                      className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                      value={newCustomer.phone}
                      onChange={e => setNewCustomer({...newCustomer, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#6a6d70]">Ad <span className="text-[#bb0000]">*</span></label>
                    <input 
                      required
                      type="text"
                      className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                      value={newCustomer.firstName}
                      onChange={e => setNewCustomer({...newCustomer, firstName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-[#6a6d70]">Soyad <span className="text-[#bb0000]">*</span></label>
                    <input 
                      required
                      type="text"
                      className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none"
                      value={newCustomer.lastName}
                      onChange={e => setNewCustomer({...newCustomer, lastName: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6a6d70]">Adres <span className="text-[#bb0000]">*</span></label>
                  <textarea 
                    required
                    rows={2}
                    className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none resize-none"
                    value={newCustomer.address}
                    onChange={e => setNewCustomer({...newCustomer, address: e.target.value})}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#6a6d70]">Özel Notlar</label>
                  <textarea 
                    rows={1}
                    className="w-full px-3 py-2 bg-white border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none resize-none"
                    value={newCustomer.notes}
                    onChange={e => setNewCustomer({...newCustomer, notes: e.target.value})}
                  />
                </div>
              </div>

              <div className="flex gap-2 justify-end pt-4 border-t border-[#f2f2f2]">
                <button 
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-6 py-1.5 text-sm font-bold text-[#32363a] hover:bg-[#f2f2f2]"
                >
                  Vazgeç
                </button>
                <button 
                  type="submit"
                  className="px-6 py-1.5 bg-[#0070b4] text-white text-sm font-bold border border-[#0070b4] hover:bg-[#005a92]"
                >
                  Müşteriyi Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;
