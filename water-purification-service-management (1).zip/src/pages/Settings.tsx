import React, { useState } from 'react';
import { 
  Lock,
  User
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const Settings: React.FC = () => {
  const { updatePassword, updateUserName, resetSystem, userNames } = useApp();
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [u1Name, setU1Name] = useState(userNames['5550240995'] || '');
  const [u2Name, setU2Name] = useState(userNames['5465307039'] || '');
  const [status, setStatus] = useState({ type: '', msg: '' });

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      setStatus({ type: 'error', msg: 'Şifre en az 4 karakter olmalıdır!' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setStatus({ type: 'error', msg: 'Şifreler uyuşmuyor!' });
      return;
    }
    updatePassword(newPassword);
    setStatus({ type: 'success', msg: 'Giriş şifresi başarıyla güncellendi.' });
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleNamesUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserName('5550240995', u1Name);
    updateUserName('5465307039', u2Name);
    setStatus({ type: 'success', msg: 'Kullanıcı isimleri güncellendi.' });
  };

  const handleReset = () => {
    if (window.confirm('TÜM VERİLER SIFIRLANACAK! Emin misiniz?')) {
      resetSystem();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <header className="mb-6">
        <h2 className="text-xl font-bold text-[#32363a]">Sistem Ayarları</h2>
        <div className="h-0.5 w-12 bg-[#0070b4] mt-1"></div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider mb-2">Kullanıcı Yönetimi</h3>
          <p className="text-xs text-[#6a6d70] leading-relaxed">
            Giriş yapan numaralara ait görünen isimleri buradan tanımlayın.
          </p>
        </div>

        <div className="md:col-span-2">
          <section className="bg-white border border-[#d9d9d9] shadow-sm">
             <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center gap-2 text-[#0070b4]">
                <User size={16} />
                <h3 className="text-xs font-bold text-[#32363a] uppercase">İsimleri Belirle</h3>
             </div>
             <form onSubmit={handleNamesUpdate} className="p-6 space-y-4">
                <div className="space-y-1.5">
                   <label className="text-[10px] font-bold text-[#6a6d70] uppercase">555 024 09 95 - İsim</label>
                   <input type="text" className="w-full px-3 py-2 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={u1Name} onChange={e => setU1Name(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                   <label className="text-[10px] font-bold text-[#6a6d70] uppercase">546 530 70 39 - İsim</label>
                   <input type="text" className="w-full px-3 py-2 border border-[#d9d9d9] text-sm focus:border-[#0070b4] outline-none" value={u2Name} onChange={e => setU2Name(e.target.value)} />
                </div>
                <button type="submit" className="px-6 py-1.5 bg-[#0070b4] text-white text-xs font-bold border border-[#0070b4] hover:bg-[#005a92]">Kaydet</button>
             </form>
          </section>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-[#d9d9d9]">
        <div className="md:col-span-1">
          <h3 className="text-sm font-bold text-[#32363a] uppercase tracking-wider mb-2">Güvenlik & Sistem</h3>
        </div>
        <div className="md:col-span-2 space-y-6">
          <section className="bg-white border border-[#d9d9d9] shadow-sm">
            <div className="px-6 py-4 border-b border-[#f2f2f2] bg-[#fcfcfc] flex items-center gap-2 text-[#0070b4]">
               <Lock size={16} />
               <h3 className="text-xs font-bold text-[#32363a] uppercase">Giriş Şifresini Değiştir</h3>
            </div>
            <form onSubmit={handlePasswordUpdate} className="p-6 space-y-4">
              {status.msg && <div className={cn("p-2 text-xs font-bold border-l-4", status.type === 'error' ? "bg-red-50 border-red-500 text-red-700" : "bg-emerald-50 border-emerald-500 text-emerald-700")}>{status.msg}</div>}
              <div className="grid grid-cols-2 gap-4">
                 <input type="password" placeholder="Yeni Şifre" className="px-3 py-2 border border-[#d9d9d9] text-sm outline-none focus:border-[#0070b4]" value={newPassword} onChange={e => setNewPassword(e.target.value)} />
                 <input type="password" placeholder="Şifre Tekrar" className="px-3 py-2 border border-[#d9d9d9] text-sm outline-none focus:border-[#0070b4]" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} />
              </div>
              <button type="submit" className="px-6 py-1.5 bg-[#0070b4] text-white text-xs font-bold border border-[#0070b4] hover:bg-[#005a92]">Şifreyi Güncelle</button>
            </form>
          </section>

          <section className="bg-[#bb0000]/5 border border-[#bb0000]/20 p-6 flex items-center justify-between">
             <div>
                <h4 className="text-sm font-bold text-[#bb0000]">Veri Sıfırlama</h4>
                <p className="text-xs text-[#6a6d70]">Tüm kayıtlar ve ayarlar kalıcı olarak silinir.</p>
             </div>
             <button onClick={handleReset} className="px-6 py-2 bg-[#bb0000] text-white text-xs font-bold hover:bg-red-700 shadow-sm transition-all uppercase tracking-widest">Sistemi Sıfırla</button>
          </section>

          <section className="mt-6 bg-[#0070b4]/5 border border-[#0070b4]/20 p-6">
             <div className="flex items-center justify-between">
                <div>
                   <h4 className="text-sm font-bold text-[#0070b4]">Manuel Veri Aktarımı (Cihaz Değişimi)</h4>
                   <p className="text-xs text-[#6a6d70]">PC'deki verileri telefona veya başka cihaza aktarmak için kullanılır.</p>
                </div>
                <div className="flex gap-2">
                   <button 
                     onClick={() => {
                       const data = {
                         customers: localStorage.getItem('customers'),
                         devices: localStorage.getItem('devices'),
                         services: localStorage.getItem('services'),
                         products: localStorage.getItem('products'),
                         appointments: localStorage.getItem('appointments'),
                         sold_products: localStorage.getItem('sold_products')
                       };
                       const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
                       const url = URL.createObjectURL(blob);
                       const a = document.createElement('a');
                       a.href = url;
                       a.download = `crm_yedek_${new Date().toISOString().split('T')[0]}.json`;
                       a.click();
                     }}
                     className="px-4 py-2 bg-[#354a5f] text-white text-[10px] font-bold uppercase tracking-widest"
                   >
                     Yedeği İndir
                   </button>
                   <button 
                     onClick={() => {
                       const input = document.createElement('input');
                       input.type = 'file';
                       input.accept = '.json';
                       input.onchange = (e: any) => {
                         const file = e.target.files[0];
                         const reader = new FileReader();
                         reader.onload = (event: any) => {
                           const data = JSON.parse(event.target.result);
                           Object.keys(data).forEach(key => {
                             if (data[key]) localStorage.setItem(key, data[key]);
                           });
                           alert('Veriler başarıyla yüklendi! Sayfa yenileniyor...');
                           window.location.reload();
                         };
                         reader.readAsText(file);
                       };
                       input.click();
                     }}
                     className="px-4 py-2 bg-white text-[#354a5f] border border-[#354a5f] text-[10px] font-bold uppercase tracking-widest"
                   >
                     Yedeği Yükle
                   </button>
                </div>
             </div>
          </section>
        </div>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

export default Settings;
