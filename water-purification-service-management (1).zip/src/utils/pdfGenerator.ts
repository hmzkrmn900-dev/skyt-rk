import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { ServiceRecord, Device, Customer, Product } from '../types';

export const generateServicePDF = (service: ServiceRecord, device: Device, customer: Customer) => {
  const doc = new jsPDF();
  const copies = ['BEYAZ NÜSHA (FİRMA)', 'KIRMIZI NÜSHA (MÜŞTERİ)', 'MAVİ NÜSHA (MUHASEBE)'];

  copies.forEach((copyTitle, index) => {
    if (index > 0) doc.addPage();

    // Header
    doc.setFillColor(53, 74, 95); 
    doc.rect(0, 0, 210, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text('SU ARITMA SERVİS FORMU', 20, 25);
    
    doc.setFontSize(9);
    doc.text(copyTitle, 160, 25);

    // Info
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('MÜŞTERİ BİLGİLERİ', 20, 50);
    doc.setFont('helvetica', 'normal');
    doc.text(`${customer.firstName} ${customer.lastName}`, 20, 57);
    doc.text(customer.phone, 20, 62);
    doc.text(customer.address, 20, 67, { maxWidth: 80 });

    doc.setFont('helvetica', 'bold');
    doc.text('CİHAZ BİLGİLERİ', 120, 50);
    doc.setFont('helvetica', 'normal');
    doc.text(`Cihaz: ${device.brand} ${device.model}`, 120, 57);
    doc.text(`Seri No: ${device.serialNumber}`, 120, 62);

    (doc as any).autoTable({
      startY: 85,
      head: [['YAPILAN İŞLEMLER']],
      body: service.operations.map(op => [op]),
      theme: 'grid',
      headStyles: { fillStyle: [53, 74, 95] }
    });
  });

  doc.save(`servis-${service.id}.pdf`);
};

export const generateProposalPDF = (customer: Customer, items: any[], products: Product[], totals: any, notes: string) => {
  const doc = new jsPDF();
  
  doc.setFillColor(53, 74, 95); 
  doc.rect(0, 0, 210, 45, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.text('SATIŞ TEKLİF FORMU', 20, 25);
  
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('MÜŞTERİ:', 20, 60);
  doc.setFont('helvetica', 'normal');
  doc.text(`${customer.firstName} ${customer.lastName}`, 20, 67);
  doc.text(`TC: ${customer.tcNumber}`, 20, 72);
  doc.text(`Adres: ${customer.address}`, 20, 77, { maxWidth: 80 });

  const tableData = items.map(item => {
    const product = products.find(p => p.id === item.productId);
    return [
      product?.name,
      item.quantity,
      `${item.unitPrice.toLocaleString('tr-TR')} TL`,
      `${(item.unitPrice * item.quantity).toLocaleString('tr-TR')} TL`
    ];
  });

  (doc as any).autoTable({
    startY: 95,
    head: [['Ürün', 'Adet', 'Birim', 'Toplam']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillStyle: [53, 74, 95] }
  });

  const finalY = (doc as any).lastAutoTable.finalY + 10;
  doc.text(`Genel Toplam: ${totals.total.toLocaleString('tr-TR')} TL (KDV Dahil)`, 120, finalY);

  if (notes) {
    doc.text('Notlar:', 20, finalY + 15);
    doc.setFontSize(8);
    doc.text(notes, 20, finalY + 22, { maxWidth: 170 });
  }

  // Force download using blob for better mobile compatibility if needed
  doc.save(`teklif-${customer.lastName || 'dosyasi'}.pdf`);
};
