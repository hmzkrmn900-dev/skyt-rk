export type UserRole = 'ADMIN' | 'OFFICE' | 'TECHNICIAN';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
}

export interface Customer {
  id: string;
  tcNumber: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  location?: { lat: number; lng: number };
  notes: string;
  notePhotos?: string[]; // Base64 or URL strings
  createdAt: string;
}

export interface Device {
  id: string; // CHZ-0001
  customerId: string;
  brand: string;
  model: string;
  serialNumber: string;
  installationDate: string;
  warrantyUntil: string;
  qrCodeUrl: string;
  filters: FilterInfo[];
}

export interface FilterInfo {
  name: string;
  lastChanged: string;
  nextChange: string;
  status: 'good' | 'warning' | 'critical';
}

export interface ServiceRecord {
  id: string;
  deviceId: string;
  technicianId: string;
  date: string;
  type: 'INSTALLATION' | 'MAINTENANCE' | 'REPAIR';
  tdsIn: number;
  tdsOut: number;
  pressure: number;
  operations: string[];
  partsChanged: string[];
  notes: string;
  photoUrls: string[];
  customerSignature: string; // Base64
  totalAmount: number;
  paymentStatus: 'PAID' | 'PENDING' | 'PARTIAL';
  paymentMethod: 'CASH' | 'CARD' | 'TRANSFER';
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
}

export interface Appointment {
  id: string;
  customerId: string;
  date: string;
  time: string;
  description: string;
  status: 'PENDING' | 'COMPLETED' | 'CANCELLED';
}

export interface ProposalItem {
  productId: string;
  quantity: number;
  unitPrice: number;
}

export interface Proposal {
  id: string;
  customerId: string;
  date: string;
  items: ProposalItem[];
  validUntil: string;
  totalAmount: number;
  notes: string;
}

export interface SoldProduct {
  id: string;
  customerId: string;
  productId: string;
  date: string;
  price: number;
  technicianId: string;
}
